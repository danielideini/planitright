$(function(){
	$("#DateRange").click(function (e) {
			// alert($("#DieticianID").val());
			e.preventDefault();
				var type = 'Type=' + $("#PM_TypeSelector").val();
				var DateFrom = '&DateFrom=' + $("#MealsDateFrom").val();
				var DateTo = '&DateTo=' + $("#MealsDateTo").val();
				var ID = '&MPPatientName=' + $("#MP_PatientName").val();
				jQuery.ajax({
				type: "POST",
				url: "../PHP/SaveNA.php",
				dataType: "text",
				data: type+DateFrom+DateTo+ID,
				
				success:function(response){
					$("#MealTable").replaceWith(response);
				},
				error:function (xhr, ajaxOptions, thrownError){
					alert(thrownError);
				}
				});
	});

	$("#PM_TypeSelector").change(function(e){
		e.preventDefault();
				var type = 'Type=' + $("#PM_TypeSelector").val();
				var DateFrom = '&DateFrom=' + $("#MealsDateFrom").val();
				var DateTo = '&DateTo=' + $("#MealsDateTo").val();
				var ID = '&MPPatientName=' + $("#MP_PatientName").val();
				jQuery.ajax({
				type: "POST",
				url: "../PHP/SaveNA.php",
				dataType: "text",
				data: type+DateFrom+DateTo+ID,
				
				success:function(response){
					$("#MealTable").replaceWith(response);
				},
				error:function (xhr, ajaxOptions, thrownError){
					alert(thrownError);
				}
				});
	});

	$("#MP_PatientName").change(function (e) {
			e.preventDefault();
				var type = 'Type=' + $("#PM_TypeSelector").val();
				var DateFrom = '&DateFrom=' + $("#MealsDateFrom").val();
				var DateTo = '&DateTo=' + $("#MealsDateTo").val();
				var ID = '&MPPatientName=' + $("#MP_PatientName").val();
				jQuery.ajax({
				type: "POST",
				url: "../PHP/SaveNA.php",
				dataType: "text",
				data: type+DateFrom+DateTo+ID,
				
				success:function(response){
					$("#MealTable").replaceWith(response);
				},
				error:function (xhr, ajaxOptions, thrownError){
					alert(thrownError);
				}
				});
	});

	$("#R_Name").change(function (e) {
			// alert($("#DieticianID").val());
			e.preventDefault();
			
				var RName = 'RecipeName=' + $("#R_Name").val();
				jQuery.ajax({
				type: "POST",
				url: "../PHP/SaveNA.php",
				dataType: "text",
				data: RName,
				
				success:function(response){
					$("#R_Table").replaceWith(response);
				},
				error:function (xhr, ajaxOptions, thrownError){
					alert(thrownError);
				}
				});
	});

	$("#R_Type").change(function (e) {
			// alert($("#DieticianID").val());
		e.preventDefault();
	
		var R_Type = 'RecipeType=' + $("#R_Type").val();
		jQuery.ajax({
		type: "POST",
		url: "../PHP/SaveNA.php",
		dataType: "text",
		data: R_Type,
		
		success:function(response){
			$("#R_Table").replaceWith(response);
		},
		error:function (xhr, ajaxOptions, thrownError){
			alert(thrownError);
		}
		});
	});

	$(".UpdateRecipe").click(function () {

		var id = $(this).attr('id');
		
		var DID = 'DieticianID=' + $(".DieticianID").val();
		var RID = '&RecipeID=' + id;

		 window.location.replace("UpdateRecipe.php?"+DID+RID);
	});


	$("#D_Logout").click(function (e) {
		swal({
		  title: "Are you sure?",
		  text: "You are about to log out!",
		  type: "warning",
		  showCancelButton: true,
		  confirmButtonColor: "#DD6B55",
		  confirmButtonText: "Yes, log me out!",
		  cancelButtonText: "No, I'll stay!",
		  closeOnConfirm: false,
		  closeOnCancel: false
		},
		function(isConfirm){
		  if (isConfirm) {
			swal("","You have successfully logged out.","success");
			setTimeout(function () {
			   window.location.replace("../Index.html")
			}, 2000);
		  } else {
			swal("Cancelled", "Thank you for staying :)", "error");
		  }
		});
	});

	$("#D_PatientName").change(function (e) {
			// alert($("#DieticianID").val());
			e.preventDefault();
			
				var D_PatientName = 'PatientName=' + $("#D_PatientName").val();
				jQuery.ajax({
				type: "POST",
				url: "../PHP/SaveNA.php",
				dataType: "text",
				data: D_PatientName,
				
				success:function(response){
					$("#PatientInfo").replaceWith(response);
				},
				error:function (xhr, ajaxOptions, thrownError){
					alert(thrownError);
				}
				});
	});

	$("#D_PatientID").change(function (e) {
			// alert($("#DieticianID").val());
			e.preventDefault();
			
				var D_PatientID = 'D_PatientID=' + $("#D_PatientID").val();
				jQuery.ajax({
				type: "POST",
				url: "../PHP/SaveNA.php",
				dataType: "text",
				data: D_PatientID,
				
				success:function(response){
					$("#PatientInfo").replaceWith(response);
				},
				error:function (xhr, ajaxOptions, thrownError){
					alert(thrownError);
				}
				});
	});
});