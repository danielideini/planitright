$(function(){

//------------ Dietician Profile --------------//
	$("#AddNewUserAccount").click(function (e) {
		e.preventDefault();
		if( $("#UFirstName").val()!="" && $("#ULastName").val()!="" && $("#ContactNumber").val()!=""
		&& $("#UserType").val()!="" && $("#LicenseNumber").val()!=""){

			var DID = 'DieticianID='+$("#DieticianID").val();	
			var FirstName = '&FirstName='+$("#UFirstName").val();
			var LastName = '&LastName='+$("#ULastName").val();
			var ContactNumber = '&ContactNumber='+$("#ContactNumber").val();
			var UserType = '&UserType='+$("#UserType").val();
			var LicenseNumber = '&LicenseNumber='+$("#LicenseNumber").val();

			jQuery.ajax({
			type: "POST",
			url: "../PHP/SaveNA.php",
			dataType: "text",
			data: DID+FirstName+LastName+ContactNumber+UserType+LicenseNumber,
			
			success:function(response){
				 $('#DieticianTable').replaceWith(response);
			},
			error:function (xhr, ajaxOptions, thrownError){
				alert(thrownError);
			}
			});
			
		}else{
			alert("Please fill in all of the inputs.");
		}
	});


	$(".DeleteUserAcct").click(function(e){

		e.preventDefault();
		var id = $(this).attr('id');

		var UserAccount = 'UserAccount='+id;
		jQuery.ajax({
		type: "POST",
		url: "../PHP/SaveNA.php",
		dataType: "text",
		data: UserAccount,
		
		success:function(response){
			 $('#DieticianTable').replaceWith(response);
		},
		error:function (xhr, ajaxOptions, thrownError){
			alert(thrownError);
		}
		});

	});

	$("#SubmitAllergy").click(function (e) {
			// alert($("#DieticianID").val());
			e.preventDefault();
			if($("#SelectedAllergy").val()== " ")
			{
				alert("You have not selected anything from allergy dropdown list.");
			}else{
				var myData = 'Allergy='+ $("#SelectedAllergy").val();
				jQuery.ajax({
				type: "POST",
				url: "../PHP/SaveNA.php?RecipeID="+$("#RecipeID").val(),
				dataType: "text",
				data: myData,
				
				success:function(response){
					$("#allergies").append(response);
				},
				error:function (xhr, ajaxOptions, thrownError){
					alert(thrownError);
				}
				});
			}
	});
	
	//------------- Update Recipes --------------//
	$("#SubmitNutriValue").click(function (e) {

			e.preventDefault();
			if($("#NutriValue").val()== " "){
				alert("You have not selected anything from allergy dropdown list.");
			}else{
				var NutriName = 'NutriName='+ $("#NutriValue").val();
				var nutriAmount = '&NutriAmount='+$("#Amount").val();
				
				// alert (nutriAmount);
				jQuery.ajax({
				type: "POST",
				url: "../PHP/SaveNA.php?RecipeID="+$("#RecipeID").val(),
				dataType: "text",
				data: NutriName+nutriAmount,
				
				success:function(response){
					$("#NutriValues").append(response);
				},
				error:function (xhr, ajaxOptions, thrownError){
					alert(thrownError);
				}
				});
			}
	});

	$(".UpdateRNutri").click(function(e) {
		e.preventDefault();
	    var id = $(this).attr('id');

	    var RepTable = 'ReplaceNutriTable='+$(this).attr('id');
		jQuery.ajax({
		type: "POST",
		url: "../PHP/SaveNA.php?RecipeID="+$("#RecipeID").val(),
		dataType: "text",
		data: RepTable,
		
		success:function(response){
			$("#NutriTable").replaceWith(response);
		},
		error:function (xhr, ajaxOptions, thrownError){
			alert(thrownError);
		}
		});

	});

	$(".SaveRNutri").click(function(e) {
		e.preventDefault();
		//alert ('nutrition');
	    var id = $(this).attr('id');

	    var RepTable = 'SaveRNutri='+$(this).attr('id');
	    var name = '&UNutriName='+$('#UNutriName').val();
	    var amount = '&UNutriAmount='+ $('#UNutriAmount').val();

		jQuery.ajax({
		type: "POST",
		url: "../PHP/SaveNA.php?RecipeID="+$("#RecipeID").val(),
		dataType: "text",
		data: RepTable+name+amount,
		
		success:function(response){

			$("#NutriTable").replaceWith(response);
		},
		error:function (xhr, ajaxOptions, thrownError){
			alert(thrownError);
		}
		});

	});

	$("#UpdateRecipe").click(function() {

		var update = 'UpdateRecipe=update'; 
	    var DID = '&DieticianID='+$('#DieticianID').val();
	    var RID = '&RecipeID='+ $('#RecipeID').val();
	    var Name = '&RecipeName='+ $('#RecipeName').val();
	    var Ingredient = '&Ingredient='+ $('#Ingredient').val();
	    var Procedures = '&Procedures='+ $('#Procedures').val();
	    var MealType = '&MealType='+ $('#MealType').val();
	   // alert(DID+RID+Name+Ingredient+Procedures+MealType);
		jQuery.ajax({
		type: "POST",
		url: "../PHP/SaveNA.php",
		dataType: "text",
		data: update+DID+RID+Name+Ingredient+Procedures+MealType,
		
		success:function(response){
			window.location.replace("AdminAddRecipe.php?"+DID);
		},
		error:function (xhr, ajaxOptions, thrownError){
			alert(thrownError);
		}
		});

	});

	
	$("#AddRecipeLink").on('click',function () {

		var EnteredName = prompt("Please enter a recipe name:", "");
		
		if (EnteredName == null || EnteredName == "") {
			
		} else {
			var DID = 'DieticianID='+$('#DieticianID').val();
			var RName = 'ARecipeName='+EnteredName;
			window.location.replace("../PHP/AddRecipe.php?"+RName+"&"+DID);
		}
	});

	$("#AddRecipeLinkAdmin").on('click',function () {	

		swal({
			  title: "Add Recipe!",
			  type: "input",
			  showCancelButton: true,
			  closeOnConfirm: false,
			  animation: "slide-from-top",
			  inputPlaceholder: "Recipe name"
			},
			function(inputValue){
			  if (inputValue === false) return false;

			  if (inputValue === "") {
			    swal.showInputError("You need to write the recipe name!");
			    return false
			  }

				var DID = 'DieticianID='+$('#DieticianID').val();
				var RName = 'ARecipeName='+inputValue;
				window.location.replace("../PHP/AdminAddRecipe.php?"+RName+"&"+DID);

			});
		
	});

	$('#P_BRefresh').click(function(){
		location.reload();
	});

	$('#P_PMRefresh').click(function(){
		location.reload();
	});

	function reload(){
		setTimeout(function () {
			window.location.reload("../DIndex.php?"+$('#DieticianID').val());
		}, 1000);
	};


});