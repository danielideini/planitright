<?php
class DPlanItRight{

	function UpdateRecipes($id){
		if(!isset($id){
		$RID = $_POST['RecipeID'];
		$sql = "SELECT * FROM recipes WHERE RecipeNum='$RID'";
		
		if(mysqli_query($con,$sql)){
					$result = $con->query($sql);
					$array = array();
					$row = mysqli_fetch_assoc($result);
					
					$RecipeName = $row['RecipeName'];
					$Ingredient = $row['Ingredient'];
					$Procedures = $row['Procedures'];
					$MealType = $row['Type'];
				}else{
					echo"Error.".mysqli_error($con);
				}

	}
	
}