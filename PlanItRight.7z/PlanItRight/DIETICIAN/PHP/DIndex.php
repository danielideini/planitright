<!DOCTYPE HTML>
<html>
<head>
	<title>DIETICIAN</title>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="../CSS/DIndex.css">
	<link rel="stylesheet" href="../CSS/sweetalert.css">
	<script src="../JS/jquery-1.11.1.min.js"></script>
	<script type="text/javascript" src="../JS/sweetalert.min.js"></script>
	<script type="text/javascript" src="../JS/NIndex.js"></script>
	<script type="text/javascript" src="../JS/Add.js"></script>
	<script type="text/javascript" src="../JS/Search.js"></script>
</head>

<body id="D_Index_Body">

<?php
	require_once "../INCLUDE/config.php";
	$DID = $_GET['DieticianID'];
	
?>

<input type="hidden" id="DieticianID" value="<?=$DID?>">
<h1 id='PlanItRight'>Plan It Right</h1>
	<div class="tab">
		<div class="dropdown">
			<a class="tablinks" onclick="openNav(event, 'Profile')">MY PROFILE</a>
				<div class="content">
					<a onclick="openNav(event, 'UpdateProfile')">Update</a>
				</div>
		</div>
		<a class="tablinks" onclick="openNav(event, 'Patients')">PATIENTS PROFILE</a>
		<a class="tablinks" onclick="openNav(event, 'PMeals')">PATIENT MEALS</a>
		
				<div class="dropdown">
					<a onclick="openNav(event, 'Recipes')" class="tablinks">RECIPES</a>
						<div class="content">
							<a id="AddRecipeLink" >AddRecipe</a>
						</div>
				</div>
		<a id="D_Logout" class="tablinks"">LOG OUT</a>
	</div>

	<div id="Profile" class="tabcontent">
	  <?php
			
			$sql = "SELECT * FROM dietician_info WHERE DNID='$DID'";
				if(mysqli_query($con,$sql)){
					$result = $con->query($sql);
					$array = array();
					$row = mysqli_fetch_assoc($result);
					$array[] = $row;
					
					$DFname = $array[0]['FirstName'];
					$DLname = $array[0]['LastName'];
					$ContactInfo = $array[0]['ContactNumber'];

				}else{
					echo"Error.".mysqli_error($con);
				}
	?>
					<h1 class='D_RHeader'> Personal Information </h1>
					<p>ID: <?=$DID?></p><br>
					<p>Name: <?=$DFname." ".$DLname?></p><br>
					<p>Contact Information: <?=$ContactInfo?></p><br>
	</div>
	
	<div id="Patients" class="tabcontent">
	<h1 class='D_RHeader'> Patients Profile</h1>
	<p class='D_PProfile'>Patient Name:  <input type="text" id="D_PatientName">
	Patient ID:  <input type="number" id="D_PatientID"></p>
	<?php
		$sql = "SELECT * FROM patient_information";
			$result = mysqli_query($con,$sql);
			echo "<table id='PatientInfo' border=1>
			<tr>
				<th>ID</th><th>NAME</th><th>BMI</th><th>CONTACT NUMBER</th>
			</tr>";
					while($row = mysqli_fetch_assoc($result)){
						echo "<tr><td class='D_PProfile D_PID'>".$row['PatientID']."</td>";
						echo "<td class='D_PProfile'>".$row['FName']." ".$row['LName']."</td>";
						echo "<td class='D_PProfile D_PBMI'>".$row['BMI']."</td>";
						echo "<td class='D_PProfile D_PContact'>".$row['ContactInfo']."</td>";
					}
					?>
			</table>


	</div>

	<div id="UpdateProfile" class="tabcontent">
		<?php 
			if(!isset($_GET['UpdateInfo'])){
		?>
		<form method="GET">
			<p>Dietician ID: <?=$DID?></p>
			<p>First Name:</p> <input class="D_UP_Inputboxes" type="text" name="FName" ></input>
			<p>Last Name: </p><input class="D_UP_Inputboxes" type="text" name="LName"></input>
			<p>Contact No.: </p> <input class="D_UP_Inputboxes" type="number" name="ContactNumber"></input><br>
			<input type="hidden" name="DieticianID" value="<?=$DID?>">
			<input id="D_UP_Save" type="submit" name="UpdateInfo" value="SAVE">
		</form>
		
		<?php
			}else{
				$Dfname = $_GET['FName'];
				$Dlname = $_GET['LName'];
				$ContactNum = $_GET['ContactNumber'];
				
				$sql="UPDATE dietician_info SET FirstName='$Dfname', LastName='$Dlname', ContactNumber='$ContactNum', Position='Dietician' WHERE DNID='$DID'";
				
				if(mysqli_query($con,$sql)){
					header("location: DIndex.php?DieticianID=".($DID));
				}else{
					echo"Error updating ".mysqli_error($con);
				}
			}
		?>
	</div>

	<div id="PMeals" class="tabcontent">
	  <h3 class='D_RHeader'>Patient Meals</h3>
	  <?php
			
			echo "<p>Date: <input class='D_PM_Inputs D_PM_Select' type='date' id='MealsDate'> ID: 
			<input class='D_PM_Inputs D_PM_ID' type='number' id='PatientID' name='MealID'></p>";
		
			$sql = "SELECT * FROM meal_plan";
			$result = mysqli_query($con,$sql);
			echo "<table id='MealTable' border=1><tr><th>DATE</th><th>Patient ID</th><th>Recipe Name</th><th>Type</th></tr>";
				while($row = mysqli_fetch_assoc($result)){
					echo "<tr><td>".$row['Date']."</td>";
					echo "<td>".$row['PatientID']."</td>";
					$sql1 = "SELECT * FROM recipes WHERE RecipeNum='".$row['RecipeID']."'";
					$result1 = mysqli_query($con,$sql1);
					 while($row1 = mysqli_fetch_assoc($result1)){
					?>
						<td  class="td"><?=$row1['RecipeName']?></td>
						<td><?=$row1['Type']?></td>
						</tr>
					<?php
						}
					}
					?>
			</table>
	</div>

	<div id="Recipes" class="tabcontent">

		<h1 class='D_RHeader' >RECIPES</h1>
		<p>Recipe Name: <input class='DR_Input' type='text' id='R_Name' name='R_Name'>	Type: <select class='DR_Input' id='R_Type'>
			<option value='B'>B</option>
			<option value="L">L</option>
			<option value="D">D</option>
		</select></p>

		<?php
			$sql = "SELECT * FROM recipes";
			$result = mysqli_query($con,$sql);
			echo "<table id='R_Table' border=1>
					<tr><div class='D_R_PFixed D_RFixed_th'>
						<th id=''>IMAGE</th>
						<th id='D_RT_Name'>NAME</th>
						<th id='D_RT_Ingredients'>INGREDIENTS</th>
						<th id='D_RT_Procedures'>PROCEDURES</th>
						<th id='D_RT_Type'>TYPE</th>
						<th id='D_RT_Type'>ACTION</th>
						</div>
					</tr>";
					
				while($row = mysqli_fetch_assoc($result)){                                                         
						?><form action='UpdateRecipe.php' method='POST'>
						<tr><td  class="pictures"><img class='pics' src=../IMAGE/<?=$row['Picture']?>></td>

						<td  class="D_RText_Centered"><?=$row['RecipeName']?></td>
						
						<td class="D_RText_Not_Centered"><?=$row['Ingredient']?></td>
						<td class="D_RText_Not_Centered"><?=$row['Procedures']?></td>
						<td class="D_RText_Centered"><?=$row['Type']?></td>
						
						<input type ='hidden' name='RecipeID' value='<?=$row['RecipeNum']?>'></input>
						<input type ='hidden' name='DieticianID' value='<?=$DID?>'></input>
						
						<td><button class="D_Recipe_Button" name="UPDATE">UPDATE</button></form>
						
						<form method='POST'>
							<input class="D_Recipe_Button" type ='submit' name='DRecipeID' id="DRecipeID" value='DELETE'>
							<input type ='hidden' name='deleteid' value='<?=$row['RecipeNum']?>'></input>
							<input type='hidden' name='DieticianID' value='".$DieticianID."'></td>
						</form></tr>
				<?php
				}
				?>
			</table>
	</div>

	<?php
			if(isset($_POST['DRecipeID'])){
				$RID=htmlentities($_POST['deleteid']);
				$DieticianID = htmlentities($_POST['DieticianID']);
				
				$sqlD = $con->prepare("DELETE FROM recipes WHERE RecipeNum =?");
				$sqlD->bind_param('s', $RID);
				$sqlD->execute();

				if($sqlD){
					//echo '<script>reload();</script>';
					//header("Refresh:0; url=DIndex.php?".$DieticianID);
				}

			}
		?>
</body>
</html>