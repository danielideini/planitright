

<link rel="stylesheet" href="../CSS/sweetalert.css">
<script src="../JS/jquery-1.11.1.min.js"></script>
<script type="text/javascript" src="../JS/sweetalert.min.js"></script>

<?php
	require_once "../INCLUDE/config.php";
	
	$username = htmlentities($_POST['Username']);
	$password = htmlentities($_POST['Password']);

	if(isset($_POST['Login'])){

		if($username=="" && $password==""){
			header("location: ../Index.html");
		}else if ($username==""){
			header("location: ../Index.html");
		}else if($password==""){
			header("location: ../Index.html");
		}else{

			$sqlstmt = $con->prepare("SELECT * FROM dietician_info WHERE Username=?");
			$sqlstmt->bind_param('s',$username);
			$sqlstmt->execute();
			
			$result = $sqlstmt->get_result();
			$array = array();
			$row = mysqli_fetch_assoc($result);

			$p_hash = $row['Password'];
			
			if(password_verify($password, $p_hash)){
				header("location: admin.php?DieticianID=".$row['DNID']);
			}else{
				echo "<script>
					alert('invalid.')
					location.replace('../index.html');
				</script>";
				//echo $password." - ".$p_hash;
			}
			
			$sqlstmt->close();
			
	 	}
	}
	// elseif(isset($_POST['Register'])){
	// 	$sqlstmt = $con->prepare("SELECT * FROM dietician_info WHERE Username = ?");
	// 	$sqlstmt->bind_param('s',$username);
	// 	$sqlstmt->execute();
		
	// 	$result = $sqlstmt->get_result();
		
	// 	 if ($result->num_rows == 1) {
	// 		 echo "Username is already taken. Please try again.";
	// 	 } else {
	// 		$sqlstmt = $con->prepare("INSERT INTO dietician_info (Username, Password) VALUES(?, ?)");
	// 		$sqlstmt->bind_param("ss", $username, $password);
	// 		$sqlstmt->execute();

	// 			 if($sqlstmt->execute()){
	// 				$last_id = $con->insert_id;
	// 				header("location: DIndex.php?DieticianID=".$last_id);
	// 			 }else{
	// 				 echo"Error in insertion ".mysqli_error($con);
	// 			 }
	// 			 $sqlstmt->close();
	// 	 }
	// }

	

