<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>DIETICIAN LOGIN</title>
	<link rel="stylesheet" href="../CSS/DIndex.css">
	<script src="../JS/jquery-1.11.1.min.js"></script>
	<script type="text/javascript" src="../JS/Add.js"></script>
</head>
<body id="D_UP_Recipe_body">

<?php
	require_once "../INCLUDE/config.php";
	
	$DID = htmlspecialchars($_GET['DieticianID']);
	$RID = htmlspecialchars($_GET['RecipeID']);
	
	$sql = "SELECT * FROM recipes WHERE RecipeNum='$RID'";
		
		if(mysqli_query($con,$sql)){
					$result = $con->query($sql);
					$array = array();
					$row = mysqli_fetch_assoc($result);
					
					$RecipeName = $row['RecipeName'];
					$Ingredient = $row['Ingredient'];
					$Procedures = $row['Procedures'];
					$MealType = $row['Type'];
				}else{
					echo"Error.".mysqli_error($con);
				}
		
?>
		<div id="D_UP_Div">
		<div class="D_UR_DivI">
		<h3 id="D_UP_Header">Update Recipe</h3>
		
		<form method="POST" enctype="multipart/form-data">
				<label>Recipe name: </label>
				<input class="D_UPR_Inputs D_UR_Inputs" type = "text" id="RecipeName" value="<?=$RecipeName?>"></input><br><br>
				<input type="hidden" id="DieticianID" value="<?=$DID?>"></input>
				<input type="hidden" id="RecipeID" name="RecipeID" value="<?=$RID?>"></input>
			
					<p>Ingredients:</p>
					<textarea class="D_UPR_Inputs" style="overflow:auto;resize:none" rows="8" cols="50" type = "text" id="Ingredient"><?php echo $Ingredient;?></textarea><br>
			<div class="D_UR_DivA">
					<label>Allergens: </label>
					<select  class="D_UPR_Inputs D_UR_Inputs" id="SelectedAllergy" name="allergy">
					  <option value=""></option>			
					  <option value="Milk">Milk</option>
					  <option value="Peanut">Peanut</option>x
					  <option value="Egg">Egg</option>
					  <option value="Treenuts">Treenuts</option>
					  <option value="Soy">Soy</option>
					  <option value="Fish">Fish</option>
					  <option value="Wheat">Wheat</option>
					  <option value="Shellfish">Shellfish</option>
					</select>

					<input class="D_UPR_Inputs D_UR_Inputs" type = "submit" id="SubmitAllergy" value="ADD"></input><br>
					<?php
						$sqlAllergies = $con->prepare("SELECT * FROM perrecipeallergies WHERE RecipeID=?");
						$sqlAllergies->bind_param('s', $RID);
						$sqlAllergies->execute();

						$sqlAResult = $sqlAllergies->get_result();
						echo "	<table border=1>
										<tr><th>Name</th><th>Action</th></tr>";
						while ($sqlARow = mysqli_fetch_assoc($sqlAResult)){
							echo "<form action='' method='post'>
										<tr>
											<td>".$sqlARow['AllergyName']."</td>
											<td><button class='DeleteAllergy'>DELETE</button></td>
											<input type='hidden' name='DieticianID' value='".$DID."'>
											<input type='hidden' name='DeleteAID' value='".$sqlARow['FPAID']."'>
										</tr>
									</form>";
						}
							echo "</table>";
						$sqlAllergies->close(); 
					?>
					<ul id="allergies">
					</ul>
			</div>
			</div>
		
			<div class="D_UR_DivP">
				<p>Procedure</p>
					<textarea class="D_UPR_Inputs" rows="6" cols="50" type = "text" id="Procedures"><?php echo $Procedures;?></textarea><br><br>
					
				<label>Nutrition Facts: </label> 
					<select  class="D_UPR_Inputs D_UR_Inputs" name="NutriValue" id="NutriValue">
					  <option value=" "></option>			
					  <option value="Fat">Fat</option>
					  <option value="Cholesterol">Cholesterol</option>
					  <option value="Saturated Fat">Saturated Fat</option>
					  <option value="Sugar">Sugar</option>
					  <option value="Sodium">Sodium</option>
					  <option value="Potassium">Potassium</option>
					  <option value="Protein">Protein</option>
					  <option value="Calories from Fat">Calories from Fat</option>
					  <option value="Vitamin A">Vitamin A</option>
					  <option value="Vitamin C">Vitamin C</option>
					  <option value="Calcuim">Calcuim</option>
					  <option value="Iron">Iron</option>
					  <option value="Total Carbohydrate">Total Carbohydrate</option>	
					</select>

					<label>Nutrition amount: </label><input class="D_UPR_Inputs D_UR_Inputs" type="text" id="Amount">
					<input class="D_UPR_Inputs D_UR_Inputs" type = "submit" id="SubmitNutriValue" value="ADD"></input>
					
					<ul id="NutriValues">
					</ul>
					<br>

					<?php
						$sqlNutri = $con->prepare("SELECT * FROM recipe_nutrition_facts WHERE RecipeID=?");
						$sqlNutri->bind_param('s', $RID);
						$sqlNutri->execute();

						$sqlNResult = $sqlNutri->get_result();

						echo "<table id='NutriTable' border=1>
										<tr><th>Name</th><th>Amount</th><th>Action</th></tr>";
						while ($sqlNRow = mysqli_fetch_assoc($sqlNResult)){
							echo "<tr>
								<td>".$sqlNRow['NutriName']."</td>
								<td>".$sqlNRow['NutriAmount']."</td>
								<td>
								<button class='UpdateRNutri' id='".$sqlNRow['NNIDNum']."'>UPDATE</button>

								<form action='' method='post'>
										<button id='DeleteRNutri'>DELETE</button>
										<input type='hidden' name='DelNutriID' value='".$sqlNRow['NNIDNum']."'>
										<input type='hidden' name='DieticianID' value='".$DID."'>
										<input type='hidden' name='RecipeID' value='".$RID."'>
									</form>
								</td></tr>";
						}
							echo "</table>";
						$sqlNutri->close(); 


						if(isset($_POST['DelNutriID'])){
							$NutriID = htmlspecialchars($_POST['DelNutriID']);

							$sqlDN = $con->prepare('DELETE FROM recipe_nutrition_facts WHERE NNIDNum=?');
							$sqlDN->bind_param('s', $NutriID);
							$sqlDN->execute();
						}
					?>
			</div >
		
			<div class="D_UR_DivMT ">
			<label>Meal Type: </label> <select  class="D_UPR_Inputs D_UR_Inputs" id="MealType" value="<?=$Type?>">
			  <option value='B'>BREAKFAST</option>			
			  <option value='L'>LUNCH</option>
			  <option value='D'>DINNER</option>
			</select>
			</div>
			
			<div>
			<input type='hidden' name='DieticianID' value="<?=$DID?>">
			<input type='hidden' name='IDToUpdate' value="<?=$RID?>">
			<input type='file' name='UploadImage'><br>
			
			<input type="submit" id="UpdateRecipe" value="SUBMIT"></input>
			</div>
		</form>
	</div>

<?php
	if(isset($_POST['DeleteAID'])) {
			$DRecipeID = htmlentities($_POST['DeleteAID']);
			$sqlDR = $con->prepare('DELETE FROM perrecipeallergies WHERE FPAID=?');
			$sqlDR->bind_param('s',$DRecipeID);

			$sqlDR->execute();

			//header("location: UpdateRecipe.php");
	}
?>

</body>
</html>
