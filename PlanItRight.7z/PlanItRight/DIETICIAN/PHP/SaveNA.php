<script src="../JS/jquery-1.11.1.min.js"></script>
<script type="text/javascript" src="../JS/Add.js"></script>
<script type="text/javascript" src="../JS/Search.js"></script>
<?php

include_once "../INCLUDE/config.php";

//---------- Dieticain Profile ------------//
if(isset($_POST['FirstName']) && isset($_POST['LastName'])){
	$DID = htmlspecialchars($_POST['DieticianID']);
	$FName = htmlspecialchars($_POST['FirstName']);
	$LName = htmlspecialchars($_POST['LastName']);
	$ContactNumber = htmlspecialchars($_POST['ContactNumber']);
	$password = 'password';
	$password_hash = password_hash($password, PASSWORD_BCRYPT, array('cost' => 12));
	$Position = htmlspecialchars($_POST['UserType']);
	$LicenseNumber = htmlspecialchars($_POST['LicenseNumber']);

	$sqlInsert = $con->prepare("INSERT INTO dietician_info (Username,Password,FirstName,LastName,ContactNumber,Position, License_Number) VALUES (?,?,?,?,?,?,?);");
	$sqlInsert->bind_param('ssssisi', $FName,$password_hash,$FName,$LName,$ContactNumber,$Position,$LicenseNumber);
	$sqlInsert->execute();
	$sqlInsert->close();

	$sql = $con->prepare("SELECT * FROM dietician_info");
	$sql->execute();

	if($result = $sql->get_result()){
			echo "<table id='DieticianTable' border=1>";
			echo "<tr><th>Name</th><th>Contact Number</th><th>User Type</th><th>Action</th></tr>";
			
		while($row = mysqli_fetch_assoc($result)){
			echo "<tr>
				<td>".$row['FirstName']." ".$row['LastName']."</td>
				<td>".$row['ContactNumber']."</td>";

			echo "<td>".$row['Position']."</td>";
			echo "<td><input type='submit' class='DeleteUserAcct' id='".$row['DNID']."' value='DELETE'/></td>";
			echo "</tr>";
		}
		echo "</table>";
		$sql->close();	

	}else{
		echo"Error.".mysqli_error($con);
	}
}

//  Delete selected dietician infos ----> dietician profile tab at the admin page
if(isset($_POST['UserAccount'])){

	$UserAccount = htmlspecialchars($_POST['UserAccount']);

	$sqlDel=$con->prepare("DELETE FROM dietician_info WHERE DNID=?");
	$sqlDel->bind_param('s', $UserAccount);
	$sqlDel->execute();
	$sqlDel->close();

	$sql = $con->prepare("SELECT * FROM dietician_info");
	$sql->execute();

		if($result = $sql->get_result()){
			echo "<table id='DieticianTable' border=1>";
			echo "<tr><th>Name</th><th>Position</th><th>License Number</th><th>Contact Number</th><th>Action</th></tr>";
			
		while($row = mysqli_fetch_assoc($result)){
			echo "<tr>
				<td>".$row['FirstName']." ".$row['LastName']."</td>
				<td>".$row['Position']."</td>
				<td>".$row['License_Number']."</td>
				<td>".$row['ContactNumber']."</td>
				<td><input type='submit' class='DeleteUserAcct' id='".$row['DNID']."' value='DELETE'></td>
			</tr>";
		}
		echo "</table>";
		$sql->close();

	}else{
		echo"Error.".mysqli_error($con);
	}
}

//---------- end of dietician profile --------- //

// ------------ Update Recipes ------------//
if(isset($_POST["Allergy"])) 
{	
	$Allergy = $_POST["Allergy"]; 
	$RID = $_GET["RecipeID"];
	
	$sqlFilter = $con->prepare("SELECT * FROM perrecipeallergies WHERE AllergyName=? AND RecipeID=?");
	$sqlFilter->bind_param('ss', $Allergy, $RID);
	$sqlFilter->execute();

	$FilterRes= $sqlFilter->get_result();
	$FilterRow= mysqli_fetch_assoc($FilterRes);
	$num = count($FilterRow);
	//echo $num;
	if($num<1){
		$sql = "INSERT INTO perrecipeallergies VALUES ('','$Allergy','$RID')";

		if(mysqli_query($con,$sql)){
			$my_id = $con->insert_id;
			echo "<li>";
			echo $Allergy."<button id='DeleteAllergy'>DELETE</button></li>";
		}else{
			 echo"Error in insertion ".mysqli_error($con);
		}
	}
}

if(isset($_POST['DeleteAllergy'])){
	$AllergyID = htmlentities($_POST['DeleteAllergy']);
	$sqlD = $con->prepare("DELETE * FROM perrecipeallergies WHERE FPAID=?");
	$sqlD->bind_param('s',$AllergyID);
	$sqlD->execute();
}

if(isset($_POST["NutriName"])) 
{	

	$NutriName = htmlentities($_POST["NutriName"]); 
	$RID = htmlentities($_GET["RecipeID"]);
	$NutriAmount = htmlentities($_POST["NutriAmount"]);
	$id = '';

	$sqlSelect = $con->prepare("SELECT * FROM recipe_nutrition_facts WHERE RecipeID=?");
	$sqlSelect->bind_param('s', $RID);
	$sqlSelect->execute();

	$sqlResult= $sqlSelect->get_result();
	$sqlRow = mysqli_fetch_assoc($sqlResult);
	$count = count($sqlRow);

	if($count>=1){
		while($sqlRow = mysqli_fetch_assoc($sqlResult)) {
			if($NutriName!="" && $NutriAmount!=""){
				if($sqlRow['NutriName'] != $NutriName){
					$sql = $con->prepare("INSERT INTO recipe_nutrition_facts VALUES (?,?,?,?);");
					$sql->bind_param('ssss', $id, $NutriName, $NutriAmount,$RID);
					$sql->execute();
					$sqlResult = $sql->get_result();
					
					$my_id = mysql_insert_id();
					echo '<li>'.$NutriName.' '.$NutriAmount.'</li>';
				}
			}	
		}
	}elseif ($count<1) {
		if($sqlRow['NutriName'] != $NutriName){
					$sql = $con->prepare("INSERT INTO recipe_nutrition_facts VALUES (?,?,?,?);");
					$sql->bind_param('ssss', $id, $NutriName, $NutriAmount,$RID);
					$sql->execute();
					$sqlResult = $sql->get_result();
					
					$my_id = $con->insert_id;
					echo '<li>'.$NutriName.' '.$NutriAmount.'</li>';
				}
	}
}

//-------Meal Plan------------------//
if(isset($_POST['DateFrom']) || isset($_POST['MPPatientName']) || isset($_POST['Type']))
{

	$DateFrom = $_POST['DateFrom'];
	$DateTo = $_POST['DateTo'];
	$MPPatientName = $_POST['MPPatientName'];
	$type=$_POST['Type'];

	if ($DateFrom!="" && $DateTo!="" && $MPPatientName!="") {
			$sql = $con->prepare("SELECT * FROM meal_view WHERE Date BETWEEN ? and ?");
			$sql->bind_param('ss', $DateFrom, $DateTo);
			$sql->execute();

			$result = $sql->get_result();

			echo "<table id='MealTable' border=1><tr>
					<th>PATIENT NAME</th>
					<th>RECIPE NAME</th>
					<th>RECIPE ALLERGENS</th>
					<th>NUTRITION VALUE</th>
					<th>MEAL TYPE</th>
					<th>DATE</th>
				</tr>";

					while($row = mysqli_fetch_assoc($result)){
						echo "<tr>
							<td  class='td'>".$row['PatientName']."</td>
							<td>".$row['RecipeName']."</td>
							<td>".$row['RecipeAllergens']."</td>
							<td>".$row['NutritionFact']."</td>
							<td>".$row['RecipeType']."</td>
							<td>".$row['Date']."</td>
						</tr>";
					}

			echo "</table>";

		}elseif ($MPPatientName!="" && $type!="") {
			$sql = $con->prepare("SELECT * FROM meal_view WHERE RecipeType=?");
			$sql->bind_param('s', $type);
			$sql->execute();

			$result = $sql->get_result();

		echo "<table id='MealTable' border=1><tr>
					<th>PATIENT NAME</th>
					<th>RECIPE NAME</th>
					<th>RECIPE ALLERGENS</th>
					<th>NUTRITION VALUE</th>
					<th>MEAL TYPE</th>
					<th>DATE</th>
				</tr>";

					while($row = mysqli_fetch_assoc($result)){
						echo "<tr>
							<td  class='td'>".$row['PatientName']."</td>
							<td>".$row['RecipeName']."</td>
							<td>".$row['RecipeAllergens']."</td>
							<td>".$row['NutritionFact']."</td>
							<td>".$row['RecipeType']."</td>
							<td>".$row['Date']."</td>
						</tr>";
					}

			echo "</table>";

		}elseif($DateFrom!="" && $DateTo){
			$sql = $con->prepare("SELECT * FROM meal_view WHERE  Date BETWEEN ? and ?");
			$sql->bind_param('ss',$DateFrom, $DateTo);
			$sql->execute();

			$result = $sql->get_result();

			echo "<table id='MealTable' border=1><tr>
					<th>PATIENT NAME</th>
					<th>RECIPE NAME</th>
					<th>RECIPE ALLERGENS</th>
					<th>NUTRITION VALUE</th>
					<th>MEAL TYPE</th>
					<th>DATE</th>
				</tr>";

					while($row = mysqli_fetch_assoc($result)){
						echo "<tr>
							<td  class='td'>".$row['PatientName']."</td>
							<td>".$row['RecipeName']."</td>
							<td>".$row['RecipeAllergens']."</td>
							<td>".$row['NutritionFact']."</td>
							<td>".$row['RecipeType']."</td>
							<td>".$row['Date']."</td>
						</tr>";
					}

			echo "</table>";

	}elseif ($MPPatientName!=''){
		$sql = $con->prepare("SELECT * FROM meal_view WHERE PatientName LIKE '$MPPatientName%'");
		//$sqlPI->bind_param('s', $MPPatientName);
		$sql->execute();

		$result = $sql->get_result();

		echo "<table id='MealTable' border=1><tr>
					<th>PATIENT NAME</th>
					<th>RECIPE NAME</th>
					<th>RECIPE ALLERGENS</th>
					<th>NUTRITION VALUE</th>
					<th>MEAL TYPE</th>
					<th>DATE</th>
				</tr>";

					while($row = mysqli_fetch_assoc($result)){
						echo "<tr>
							<td  class='td'>".$row['PatientName']."</td>
							<td>".$row['RecipeName']."</td>
							<td>".$row['RecipeAllergens']."</td>
							<td>".$row['NutritionFact']."</td>
							<td>".$row['RecipeType']."</td>
							<td>".$row['Date']."</td>
						</tr>";
					}

			echo "</table>";

		}elseif ($type!=''){
		$sql = $con->prepare("SELECT * FROM recipes WHERE Type=?");
		$sql->bind_param('s', $type);
		$sql->execute();

		$result = $sql->get_result();

		echo "<table id='MealTable' border=1><tr>
					<th>PATIENT NAME</th>
					<th>RECIPE NAME</th>
					<th>RECIPE ALLERGENS</th>
					<th>NUTRITION VALUE</th>
					<th>MEAL TYPE</th>
					<th>DATE</th>
				</tr>";

					while($row = mysqli_fetch_assoc($result)){
						echo "<tr>
							<td  class='td'>".$row['PatientName']."</td>
							<td>".$row['RecipeName']."</td>
							<td>".$row['RecipeAllergens']."</td>
							<td>".$row['NutritionFact']."</td>
							<td>".$row['RecipeType']."</td>
							<td>".$row['Date']."</td>
						</tr>";
					}

			echo "</table>";
		}
}
//--------------- end of meal plan ---------------//

//--------------- Search Recipe ------------------//
if(isset($_POST["RecipeName"])) 
{
	$RName = $_POST['RecipeName'];
	$sql = $con->prepare("SELECT * FROM recipe_view WHERE RecipeName LIKE '$RName%'");
	$sql->execute();


	$result = $sql->get_result();
	$row = mysqli_fetch_assoc($result);


	echo "<table id='R_Table' border=1>
					<tr><div class='D_R_PFixed D_RFixed_th'>
						<th id=''>IMAGE</th>
						<th id='D_RT_Name'>NAME</th>
						<th id='D_RT_Ingredients'>INGREDIENTS</th>
						<th id='D_RT_Procedures'>PROCEDURES</th>
						<th id='D_RT_Type'>TYPE</th>
						<th id='D_RT_Allergen'>ALLERGENS</th>
						<th id='D_RT_Nutri'>NUTRITION</th>
						<th id='D_RT_Type'>ACTION</th>
						</div>
					</tr>";
					
				while($row = mysqli_fetch_assoc($result)){                                                         

					echo "<tr><td class='pictures'><img class='pics' src='../IMAGE/".$row['Picture']."'></td>

							<td  class='D_RText_Centered'>".$row['RecipeName']."</td>
							
							<td class='D_RText_Not_Centered'>".$row['Ingredient']."</td>
							<td class='D_RText_Not_Centered'>".$row['Procedures']."</td>
							<td class='D_RText_Centered'>".$row['Type']."</td>

							<td class='D_RText_Not_Centered'>".$row['RecipeAllergens']."</td>
							<td class='D_RText_Centered'>".$row['NutritionFact']."</td>
							
							<td><button class='D_Recipe_Button UpdateRecipe' id='".$row['RecipeNum']."'>UPDATE</button>
							
							<form action='' method='POST'><input class='D_Recipe_Button' type ='submit' name='delete' value='DELETE'>
							<input type ='hidden' name='deleteid' value='".$row['RecipeNum']."'></input>
							<input type='hidden' name='DieticianID' value=''></td>
						</form></tr>";
				}
			echo "</table>";

}elseif(isset($_POST["RecipeType"])){
	$RType = $_POST['RecipeType'];
	$sql = $con->prepare("SELECT * FROM recipe_view WHERE Type=?");
	$sql->bind_param('s', $RType);
	$sql->execute();

	$result = $sql->get_result();
	$row = mysqli_fetch_assoc($result);

	echo "<table id='R_Table' border=1>
					<tr><div class='D_R_PFixed D_RFixed_th'>
						<th id=''>IMAGE</th>
						<th id='D_RT_Name'>NAME</th>
						<th id='D_RT_Ingredients'>INGREDIENTS</th>
						<th id='D_RT_Procedures'>PROCEDURES</th>
						<th id='D_RT_Type'>TYPE</th>
						<th id='D_RT_Allergen'>ALLERGENS</th>
						<th id='D_RT_Nutri'>NUTRITION</th>
						<th id='D_RT_Type'>ACTION</th>
						</div>
					</tr>";
					
				while($row = mysqli_fetch_assoc($result)){                                                         

					echo "<tr><td class='pictures'><img class='pics' src='../IMAGE/".$row['Picture']."'></td>

							<td  class='D_RText_Centered'>".$row['RecipeName']."</td>
							
							<td class='D_RText_Not_Centered'>".$row['Ingredient']."</td>
							<td class='D_RText_Not_Centered'>".$row['Procedures']."</td>
							<td class='D_RText_Centered'>".$row['Type']."</td>

							<td class='D_RText_Not_Centered'>".$row['RecipeAllergens']."</td>
							<td class='D_RText_Centered'>".$row['NutritionFact']."</td>
							
							<td><button class='D_Recipe_Button UpdateRecipe' id='".$row['RecipeNum']."'>UPDATE</button>
							
							<form action='' method='POST'><input class='D_Recipe_Button' type ='submit' name='delete' value='DELETE'>
							<input type ='hidden' name='deleteid' value='".$row['RecipeNum']."'></input>
							<input type='hidden' name='DieticianID' value=''></td>
						</form></tr>";
				}
			echo "</table>";
}

// Patients profile

if (isset($_POST['PatientName'])) {
	$PatientName=$_POST['PatientName'];
	$sql = "SELECT * FROM pinfo_view WHERE PatientName LIKE '$PatientName%'";
	$result = mysqli_query($con,$sql);

	echo "<table id='PatientInfo' border=1>
			<tr>
				<th>ID</th><th>NAME</th><th>AGE</th><th>HEIGHT</th><th>WEIGHT</th>
				<th>BMI</th><th>GENDER</th><th>CONTACT NUMBER</th><th>ALLERGIES</th>
			</tr>";
			
			while($row = mysqli_fetch_assoc($result)){

				echo "<tr><td class='D_PProfile D_PID'>".$row['PatientID']."</td>";
				echo "<td class='D_PProfile'>".$row['PatientName']."</td>";
				echo "<td class='D_PProfile D_PBMI'>".$row['Age']."</td>";
				echo "<td class='D_PProfile D_PContact'>".$row['Height']."</td>";
				echo "<td class='D_PProfile D_PID'>".$row['Weight']."</td>";
				echo "<td class='D_PProfile'>".$row['BMI']."</td>";
				echo "<td class='D_PProfile D_PBMI'>".$row['Gender']."</td>";
				echo "<td class='D_PProfile D_PContact'>".$row['ContactInfo']."</td>";
				echo "<td class='D_PProfile D_PContact'>".$row['Allergies']."</td></tr>";

			}

				echo "</table>";

}else if (isset($_POST['D_PatientID'])) {
	$D_PatientID=$_POST['D_PatientID'];
	$sql = "SELECT * FROM patient_information WHERE PatientID='$D_PatientID'";
			$result = mysqli_query($con,$sql);
			echo "<table id='PatientInfo' border=1>
			<tr>
				<th>ID</th><th>NAME</th><th>BMI</th><th>CONTACT NUMBER</th>
			</tr>";
					while($row = mysqli_fetch_assoc($result)){
						echo "<tr><td class='D_PProfile D_PID'>".$row['PatientID']."</td>";
						echo "<td class='D_PProfile'>".$row['FName']." ".$row['LName']."</td>";
						echo "<td class='D_PProfile D_PBMI'>".$row['BMI']."</td>";
						echo "<td class='D_PProfile D_PContact'>".$row['ContactInfo']."</td>";
					}
			echo "</table>";
}

//------------Nutrition Table ---------------//

if(isset($_POST['ReplaceNutriTable'])){

	if(!isset($_POST['SaveRNutri'])){
	$NutriID = htmlspecialchars($_POST['ReplaceNutriTable']);

	$sqlNTR = $con->prepare("SELECT * FROM recipe_nutrition_facts WHERE NNIDNum=?");
	$sqlNTR->bind_param('s', $NutriID);
	$sqlNTR->execute();


	$sqlNTResult = $sqlNTR->get_result();
	$sqlNTRow = mysqli_fetch_assoc($sqlNTResult);

	echo "<table id='NutriTable' border=1>
		<tr><th>Name</th><th>Amount</th><th>Action</th></tr>
		<tr>
			<form action='SaveNA.php' method='post'>
				<td><input type='text' id='UNutriName' name='UNutriName' value='".$sqlNTRow['NutriName']."'/></td>
				<td><input type='text' id='UNutriAmount' name='UNutriAmount'  value='".$sqlNTRow['NutriAmount']."'/></td>
					<td>
						<button class='SaveRNutri' id='".$NutriID."'>Save</button>
					</td>
			</form>
		</tr>

	</table>";
	}
}

if(isset($_POST['SaveRNutri'])){

		$NutriID = htmlspecialchars($_POST['SaveRNutri']);
		$Name = htmlspecialchars($_POST['UNutriName']);
		$Amount = htmlspecialchars($_POST['UNutriAmount']);

		$sqlUpdt = $con->prepare("UPDATE recipe_nutrition_facts SET NutriName=?, NutriAmount=? WHERE NNIDNum=?");
		$sqlUpdt->bind_param('sss', $Name, $Amount, $NutriID);
		$sqlUpdt->execute();

		$sqlNutri = $con->prepare("SELECT * FROM recipe_nutrition_facts WHERE RecipeID=?");
		$sqlNutri->bind_param('s', $RID);
		$sqlNutri->execute();

		$sqlNResult = $sqlNutri->get_result();

		echo "<table id='NutriTable' border=1>
						<tr><th>Name</th><th>Amount</th><th>Action</th></tr>";
		while ($sqlNRow = mysqli_fetch_assoc($sqlNResult)){
			echo "<tr>
				<td>".$sqlNRow['NutriName']."</td>
				<td>".$sqlNRow['NutriAmount']."</td>
				<td>
				<button class='UpdateRNutri' id='".$sqlNRow['NNIDNum']."'>UPDATE</button>

				<form action='' method='post'>
						<button id='DeleteRNutri'>DELETE</button>
						<input type='hidden' name='DelNutriID' value='".$sqlNRow['NNIDNum']."'>
						<input type='hidden' name='DieticianID' value='".$DID."'>
						<input type='hidden' name='RecipeID' value='".$RID."'>
					</form>
				</td></tr>";
		}
			echo "</table>";
		$sqlNutri->close(); 
}

if(isset($_POST['UpdateRecipe'])){
		
		$DID = htmlspecialchars($_POST['DieticianID']);
		$RID = htmlspecialchars($_POST['RecipeID']);
		$RecipeName = htmlspecialchars($_POST['RecipeName']);
		$Ingredient = htmlspecialchars($_POST['Ingredient']);
		$Procedures = htmlspecialchars($_POST['Procedures']);
		$MealType = htmlspecialchars($_POST['MealType']);
		$Image = basename($_FILES['photo']['name']);
		
		if(isset($_POST['AddRecipe'])){
			$target_dir = "../IMAGE/";
			
		    $target_file = $target_dir.basename($_FILES["photo"]["name"]);

			if(file_exists("../IMAGE/" . $_FILES["photo"]["name"])){
                echo $_FILES["photo"]["name"] . " is already exists.";
            } else{
                move_uploaded_file($_FILES["photo"]["tmp_name"], "../IMAGE/" . $_FILES["photo"]["name"]);
                $image=$_FILES["photo"]["name"]; // used to store the filename in a variable

				$sqlUpdate = $con->prepare("UPDATE recipes SET RecipeName=?, Ingredient=?, Procedures=?, Type=?, Picture=? WHERE RecipeNum=?");
				$sqlUpdate->bind_param('sssssi', $RecipeName,$Ingredient,$Procedures,$MealType,$Image,$RID);
				$sqlUpdate->execute();

                echo "<script> alert(Your file was uploaded successfully.)</script>";
            }
        } 
}


