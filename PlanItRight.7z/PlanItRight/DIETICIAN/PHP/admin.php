<!DOCTYPE HTML>
<html>
<head>
	<title>DIETICIAN</title>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="../CSS/DIndex.css">
	<link rel="stylesheet" href="../CSS/sweetalert.css">
	<script src="../JS/jquery-1.11.1.min.js"></script>
	<script type="text/javascript" src="../JS/sweetalert.min.js"></script>
	<script type="text/javascript" src="../JS/NIndex.js"></script>
	<script type="text/javascript" src="../JS/Add.js"></script>
	<script type="text/javascript" src="../JS/Search.js"></script>
</head>

<body id="D_Index_Body">

	<?php
		require_once "../INCLUDE/config.php";
		$DID = htmlspecialchars($_GET['DieticianID']);
	?>
	<h1 id='PlanItRight'>Plan It Right</h1>
	<input type="hidden" id="DieticianID" value="<?=$DID?>">

	<div class="tab">

		<div class="dropdown">
			<a class="tablinks" onclick="openNav(event, 'Profile')">MY PROFILE</a>
				<div class="content">
					<a onclick="openNav(event, 'UpdateProfile')">UPDATE</a>
				</div>
		</div>

		<a class="tablinks" onclick="openNav(event, 'Dieticians')">DIETICIANS PROFILE</a>
		<a class="tablinks" onclick="openNav(event, 'Patients')">PATIENTS PROFILE</a>
		<a class="tablinks" onclick="openNav(event, 'PMeals')">PATIENT MEALS</a>
		
				<div class="dropdown">
					<a onclick="openNav(event, 'Recipes')" class="tablinks">RECIPES</a>
						<div class="content">
							<a id="AddRecipeLinkAdmin" >AddRecipe</a>
						</div>
				</div>
		<a id="D_Logout" class="tablinks"">LOG OUT</a>
	</div>

	<div id="Profile" class="tabcontent">
	  <?php
	  if(isset($_GET['DieticianID'])){
			$sql = $con->prepare ("SELECT * FROM dietician_info WHERE DNID=?");
			$sql->bind_param('s',$DID);

			$sql->execute();

				if($result = $sql->get_result()){
					$row = mysqli_fetch_assoc($result);

					echo "<h1 class='D_RHeader'> Personal Information </h1>";
					echo "<p>ID: ".$DID."</p><br>";
					echo "<p>Name: ".$row['FirstName']." ".$row['LastName']."</p><br>";
					echo "<p>Position: ".$row['Position']."</p><br>";
					echo "<p>License #: ".$row['License_Number']."</p><br>";
					echo "<p>Contact Number: ".$row['ContactNumber']."</p><br>";
					$sql->close();
				}else{
					echo"Error.".mysqli_error($con);
				}
	  }
	?>
	</div>

	<div id="UpdateProfile" class="tabcontent">
		<?php 
			if(!isset($_POST['UpdateInfo'])){
		?>
		<form method="POST">
			<p>Dietician ID: <?=$DID?></p>
			
			<?php
				$sql=$con->prepare("SELECT * FROM dietician_info WHERE DNID=?");
				$sql->bind_param('i', $DID);
				$sql->execute();

				$result=$sql->get_result();
				$row= mysqli_fetch_assoc($result);

			?>

			<p>First Name: <input class="D_UP_Inputboxes" type="text" name="FName" value="<?=$row['FirstName']?>"></input></p>
			<p>Last Name: <input class="D_UP_Inputboxes" type="text" name="LName"  value="<?=$row['LastName']?>"></input></p>

			<p>Username: <input class="D_UP_Inputboxes" type="text" name="Username"  value="<?=$row['Username']?>"></input></p>
			<p>Password: <input class="D_UP_Inputboxes" type="password" name="Password"  value="<?=$row['Password']?>"></input></p>

			<p>Position: <input class="D_UP_Inputboxes" type="text" name="Position"  value="<?=$row['Position']?>"></input> </p>

			<p>License #: <input class="D_UP_Inputboxes" type="text" name="License"  value="<?=$row['License_Number']?>"></input> </p>
			
			<p>Contact No.:  <input class="D_UP_Inputboxes" type="text" name="ContactNumber"  value="<?=$row['ContactNumber']?>"></input></p>

			<input type="hidden" name="DieticianID" value="<?=$DID?>">

			<input id="D_UP_Save" type="submit" name="UpdateInfo" value="SAVE">
		</form>
		
		<?php
			}else if (isset($_POST['UpdateInfo'])){

				$Dfname = htmlspecialchars($_POST['FName']);
				$Dlname = htmlspecialchars($_POST['LName']);
				$ContactNum = htmlspecialchars($_POST['ContactNumber']);
				$Username = htmlspecialchars($_POST['Username']);
				$Password = htmlspecialchars($_POST['Password']);
				$License_Number = htmlspecialchars($_POST['License']);
				$Position = htmlspecialchars($_POST['Position']);

				$password_hash = password_hash($Password, PASSWORD_BCRYPT, array('cost' => 12));

				$sql=$con->prepare("UPDATE dietician_info SET Username=?, Password=?, FirstName=?, LastName=?, ContactNumber=?, License_Number=?, Position=? WHERE DNID=?");
				
				$sql->bind_param('sssssisi',$Username,$password_hash,$Dfname,$Dlname,$ContactNum,$License_Number,$Position,$DID);
				$sql->execute();
				$sql->close();


				echo"
					<script>
						swal('','Successfully updated!','success');
						setTimeout(function(){
							location.replace('admin.php?DieticianID=$DID');
						}, 3000);
					</script>
				";

			}
		?>
	</div>
	
	<div id="Dieticians" class="tabcontent">

		<h1 class='D_RHeader'>Dieticians Profile</h1>

		<div id='AddUserAccount'>
			<p>First Name: <input type="text" id="UFirstName"></p>
			<p>Last Name: <input type="text" id="ULastName"></p>
			<p>License Number: <input type="text" id="LicenseNumber"></p>
			<p>Contact Number: <input type="text" id="ContactNumber"></p>

				<label>User Type: </label><select id="UserType">
					<option></option>
					<option class="D-Option" value="admin">Admin</option>
					<option class="D-Option" value="user">User</option>
				</select>

			<input type='submit' id='AddNewUserAccount' value="ADD NEW USER"/>
		</div>
		
		<div id='UserAccounts'>
		<?php
			$sql = $con->prepare("SELECT * FROM dietician_info");
			$sql->execute();

			if($result = $sql->get_result()){
					echo "<table id='DieticianTable' border=1>";
					echo "<tr><th>Name</th><th>Position</th><th>License Number</th><th>Contact Number</th><th>Action</th></tr>";
					
				while($row = mysqli_fetch_assoc($result)){
					echo "<tr>
						<td>".$row['FirstName']." ".$row['LastName']."</td>
						<td>".$row['Position']."</td>
						<td>".$row['License_Number']."</td>
						<td>".$row['ContactNumber']."</td>
						<td><input type='submit' class='DeleteUserAcct' id='".$row['DNID']."' value='DELETE'></td>
					</tr>";
				}

				echo "</table>";
				$sql->close();

			}else{
				echo"Error.".mysqli_error($con);
			}	
		?>
		</div>
	</div>

	<div id="Patients" class="tabcontent">
		<h1 class='D_RHeader'> Patients Profile</h1>

			<p class='D_PProfile'>
				Patient Name:  <input type="text" id="D_PatientName">
				Patient ID: <input type="number" id="D_PatientID">
				<button id='P_BRefresh'>REFRESH</button>
			</p>

				<?php

					$sql = $con->prepare("SELECT * FROM pinfo_view");
					$sql->execute();
					$result = $sql->get_result();

					echo "<table id='PatientInfo' border=1>
					<tr>
						<th>ID</th><th>NAME</th><th>AGE</th><th>HEIGHT</th><th>WEIGHT</th>
						<th>BMI</th><th>GENDER</th><th>CONTACT NUMBER</th><th>ALLERGIES</th>
					</tr>";
					
					while($row = mysqli_fetch_assoc($result)){

						echo "<tr><td class='D_PProfile D_PID'>".$row['PatientID']."</td>";
						echo "<td class='D_PProfile'>".$row['PatientName']."</td>";
						echo "<td class='D_PProfile D_PBMI'>".$row['Age']."</td>";
						echo "<td class='D_PProfile D_PContact'>".$row['Height']."</td>";
						echo "<td class='D_PProfile D_PID'>".$row['Weight']."</td>";
						echo "<td class='D_PProfile'>".$row['BMI']."</td>";
						echo "<td class='D_PProfile D_PBMI'>".$row['Gender']."</td>";
						echo "<td class='D_PProfile D_PContact'>".$row['ContactInfo']."</td>";
						echo "<td class='D_PProfile D_PContact'>".$row['Allergies']."</td></tr>";

					}

						$sql->close();
						echo "</table>";
					?>
	</div>

	<div id="PMeals" class="tabcontent">
	  <h3 class='D_RHeader'>Patient Meals</h3>
		  	<?php
				
				echo "<p>
							Date Range: 
								<input class='D_PM_Inputs D_PM_Select' type='date' id='MealsDateFrom'>
								<input class='D_PM_Inputs D_PM_Select' type='date' id='MealsDateTo'>

								<button id='DateRange'>SEARCH</button>
						 	NAME: 
						 		<input class='D_PM_Inputs D_PM_Name' type='text' id='MP_PatientName' name='MealID'>

						 <select id='PM_TypeSelector'>
						 	<option></option>
						 	<option value='B'>Breakfast</option>
						 	<option value='L'>Lunch</option>
						 	<option value='D'>Dinner</option>
						 </select>

						 <button id='P_PMRefresh'>REFRESH</button>

				</p>";
			
				$sql = $con->prepare("SELECT * FROM meal_view");
				$sql->execute();
				$result = $sql->get_result();

				echo "<table id='MealTable' border=1>
						<tr><th>PATIENT NAME</th><th>RECIPE NAME</th><th>RECIPE ALLERGENS</th><th>NUTRITION VALUE</th><th>MEAL TYPE</th><th>DATE</th></tr>";

					while($row = mysqli_fetch_assoc($result)){
						echo "<tr>
							<td  class='td'>".$row['PatientName']."</td>
							<td>".$row['RecipeName']."</td>
							<td>".$row['RecipeAllergens']."</td>
							<td>".$row['NutritionFact']."</td>
							<td>".$row['RecipeType']."</td>
							<td>".$row['Date']."</td>
						</tr>";
					}
			?>
			</table>
	</div>

	<div id="Recipes" class="tabcontent">
		<h1 class='D_RHeader' >RECIPES</h1>

		<p>Recipe Name: <input class='DR_Input' type='text' id='R_Name' name='R_Name'>
			Type: <select class='DR_Input' id='R_Type'>
				<option value='B'>B</option>
				<option value="L">L</option>
				<option value="D">D</option>
			</select></p>

		<?php
			$sql = "SELECT * FROM recipe_view";
			$result = mysqli_query($con,$sql);

			echo "<table id='R_Table' border=1>
					<tr><div class='D_R_PFixed D_RFixed_th'>
						<th id=''>IMAGE</th>
						<th id='D_RT_Name'>NAME</th>
						<th id='D_RT_Ingredients'>INGREDIENTS</th>
						<th id='D_RT_Procedures'>PROCEDURES</th>
						<th id='D_RT_Type'>MEAL TYPE</th>
						<th id='D_RT_Allergen'>ALLERGENS</th>
						<th id='D_RT_Nutri'>NUTRITION</th>
						<th id='D_RT_Type'>ACTION</th>
						</div>
					</tr>";
					
				while($row = mysqli_fetch_assoc($result)){                                                         

					echo "<tr><td class='pictures'><img class='pics' src='../IMAGE/".$row['Picture']."'></td>

							<td  class='D_RText_Centered'>".$row['RecipeName']."</td>
							
							<td class='D_RText_Not_Centered'>".$row['Ingredient']."</td>
							<td class='D_RText_Not_Centered'>".$row['Procedures']."</td>
							<td class='D_RText_Centered'>".$row['Type']."</td>

							<td class='D_RText_Not_Centered'>".$row['RecipeAllergens']."</td>
							<td class='D_RText_Centered'>".$row['NutritionFact']."</td>
							
							<td><button class='D_Recipe_Button UpdateRecipe' id='".$row['RecipeNum']."'>UPDATE</button>
							
							<form action='' method='POST'><input class='D_Recipe_Button' type ='submit' name='delete' value='DELETE'>
							<input type ='hidden' name='deleteid' value='".$row['RecipeNum']."'></input>
							<input type='hidden' name='DieticianID' value=''></td>
						</form></tr>";
				}
			echo "</table>";
			?>
	</div>

	<?php
			if(isset($_POST['delete'])){
				$RID=htmlentities($_POST['deleteid']);
				
				$sqlD = $con->prepare("DELETE FROM recipes WHERE RecipeNum =?");
				$sqlD->bind_param('s', $RID);
				$sqlD->execute();

			}
	?>

</body>
</html>