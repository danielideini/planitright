<link rel="stylesheet" href="../CSS/DIndex.css">
<script src="../JS/jquery-1.11.1.min.js"></script>
<script type="text/javascript" src="../JS/Add.js"></script>

<?php
	require_once "../INCLUDE/config.php";

	$DID = htmlspecialchars($_GET['DieticianID']);

	if(isset($_GET['ARecipeName']) && !isset($_POST['AddRecipe'])){
		$RecipeName = htmlspecialchars($_GET['ARecipeName']);

		$sqlAdd = $con->prepare("INSERT INTO recipes SET RecipeName=?");
		$sqlAdd->bind_param('s',$RecipeName);
		$sqlAdd->execute();
		$last_id = $con->insert_id;
	}

	if(!isset($_POST['AddRecipe'])){
?>
		<h3>Add Recipe</h3>
		
		<form method="POST" enctype="multipart/form-data">
		
		<label>Name</label>
			<input type = "text" name="RecipeName" id="RecipeName" value="<?=$_GET['ARecipeName']?>"></input><br><br>
			<input type="hidden" name="DieticianID" id="DieticianID" value="<?=$DID?>"></input>
			<input type="hidden" id="RecipeID" name="RecipeID" value="<?=$last_id?>"></input>
		
		<label>Add an Ingredient </label>
			<textarea style="overflow:auto;resize:none" rows="4" cols="50" type = "text" name="Ingredient"></textarea><br>
			
		<label>Allery: </label> 
			<select id="SelectedAllergy" name="allergy">
			  <option value=""></option>			
			  <option value="Milk">Milk</option>
			  <option value="Peanut">Peanut</option>
			  <option value="Egg">Egg</option>
			  <option value="Treenuts">Treenuts</option>
			  <option value="Soy">Soy</option>
			  <option value="Fish">Fish</option>
			  <option value="Wheat">Wheat</option>
			  <option value="Shellfish">Shellfish</option>
			</select>
			<input type = "submit" id="SubmitAllergy" value="ADD"></input><br>
			<ol id="allergies">
			</ol>
			<br>
		
		<label>Procedure</label>
			<textarea rows="4" cols="50" type = "text" name="Procedures" id="Procedures"></textarea><br><br>
			
			<label>Nutrition Facts: </label> 
			<select name="NutriValue" id="NutriValue">
			  <option value=" "></option>			
			  <option value="Fat">Fat</option>
			  <option value="Cholesterol">Cholesterol</option>
			  <option value="Saturated Fat">Saturated Fat</option>
			  <option value="Sugar">Sugar</option>
			  <option value="Sodium">Sodium</option>
			  <option value="Potassium">Potassium</option>
			  <option value="Protein">Protein</option>
			  <option value="Calories from Fat">Calories from Fat</option>
			  <option value="Vitamin A">Vitamin A</option>
			  <option value="Vitamin C">Vitamin C</option>
			  <option value="Calcuim">Calcuim</option>
			  <option value="Iron">Iron</option>
			  <option value="Total Carbohydrate">Total Carbohydrate</option>	
			</select><br>
			<label>Nutrition amount: </label><input type="text" id="Amount"><br>
			<input type = "submit" id="SubmitNutriValue" value="ADD"></input><br>
			<ul id="NutriValues">
			</ul>
			<br>
			
			<label>Meal Type: </label> <select name="MealType">
			  <option value='B'>BREAKFAST</option>			
			  <option value='L'>LUNCH</option>
			  <option value='D'>DINNER</option>
			</select><br>
			
			<label>Choose photo: </label>
			<input type="file" name="imageUpload" id="imageUpload"><br>
			
			<input type="submit" name="AddRecipe" value="SUBMIT"></input>
			
		</form>

	<?php
	}else{
		
		$RecipeID = htmlspecialchars($_POST['RecipeID']);
		$RecipeName = htmlspecialchars($_POST['RecipeName']);
		$Ingredient = htmlspecialchars($_POST['Ingredient']);
		$Procedures = htmlspecialchars($_POST['Procedures']);
		$MealType = htmlspecialchars($_POST['MealType']);

		if(isset($_POST['AddRecipe'])){
			$target_dir = "../IMAGE/";

		    $target_file = $target_dir.basename($_FILES["photo"]["name"]);

			if(file_exists("../IMAGE/" . $_FILES["photo"]["name"])){
                echo $_FILES["photo"]["name"] . " is already exists.";
            } else{
                move_uploaded_file($_FILES["photo"]["tmp_name"], $target_dir . $_FILES["photo"]["name"]);
                $image=$_FILES["photo"]["name"]; // used to store the filename in a define_syslog_variables()	

				$sql = $con->prepare("UPDATE recipes SET RecipeName=?,Ingredient=?,Procedures=?, Type=?, Picture=? WHERE RecipeNum=?");
				$sql->bind_param('sssssi', $RecipeName, $Ingredient, $Procedures, $MealType, $image, $RecipeID);
				$sql->execute();
                echo "<script> alert('Your file was uploaded successfully.');</script>";
            } 
 
			
		   
		    
			
			//header("location: ../PHP/DIndex.php?DieticianID=".$DID);
		}
			
	}

	
