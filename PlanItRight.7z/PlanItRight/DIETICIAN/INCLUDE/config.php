<?php
	$user = 'root'; 
	$password ='';
	$host = 'localhost';
	$dbname = 'foodplanner';	
	
	$con = mysqli_connect($host,$user,$password,$dbname);
	
	if(!$con){
		die("Error in connection".mysqli_connect_error());
	}else{
		//echo"<br><h3>Connection Success</h3>";
	}
?>
