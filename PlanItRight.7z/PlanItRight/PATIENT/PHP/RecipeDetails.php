<!DOCTYPE HTML>
<html>
<head>
	<title>DIETICIAN</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="../CSS/Index.css">
	<script src="../JS/jquery-1.11.1.min.js"></script>
	<script type="text/javascript" src="../JS/PIndex.js"></script>
	
</head>

<body id="RecipeDetailsBody">
	<?php
		require_once "../INCLUDE/config.php";
		$date = date("Y-m-d");
		$RID = $_POST['RecipeNum'];
		$PID = $_POST['PatientID'];
		// echo $RID;
		// echo $PID;
		if(isset($_POST['Type'])){
		$sql = "SELECT * FROM recipes where RecipeNum = '$RID'";
		$result = mysqli_query($con,$sql);
			if(mysqli_query($con,$sql)){
					$row = mysqli_fetch_assoc($result);
					echo "<h1>".$row['RecipeName']."</h1><br><h2>Ingredients</h2><p>".$row['Ingredient']."</p>
						<h2>Procedures</h2>".$row['Procedures']."<h2>Nutrition Facts</h2>";
						$sql = "SELECT * FROM recipe_nutrition_facts where RecipeID = '$RID'";
						$rslt = mysqli_query($con,$sql);
							if(mysqli_query($con,$sql)){
								while($row = mysqli_fetch_assoc($rslt))
								{
									echo "<p>".$row['NutriName']." ".$row['NutriAmount']."</p>";
								}
							}else{
								echo"Error reading ".mysqli_error($con);
								mysqli_close($con);
							}
							
					echo "<form method='POST' action='SaveMeal.php'><input id='btnAddToMealPlan' type='submit' name='AddToMealsPlan' value='ADD TO MEAL PLAN'>
						<input type='hidden' name='RecipeID' value='".$RID."'>
						<input type='hidden' name='PatientID' value='".$PID."'></form>";
				}else{
					echo"Error reading ".mysqli_error($con);
					mysqli_close($con);
				}
		}elseif(isset($_POST['remove'])){
			
			$RID = $_POST['RecipeNum'];
			$PID = $_POST['PatientID'];
			
			$sql="DELETE FROM meal_plan where Date='$date' AND RecipeID='$RID' AND PatientID='$PID'";
			if(mysqli_query($con,$sql)){
				mysqli_close($con);
				header("location: Index.php?PatientID=".$PID);
			}else{
				echo"Error reading ".mysqli_error($con);
				mysqli_close($con);
			}
		}
	?>
	

	<h1></h1>
</body>
</html>