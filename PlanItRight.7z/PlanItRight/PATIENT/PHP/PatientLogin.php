<?php
	require_once "../INCLUDE/config.php";
	
	$username = htmlentities($_GET['Username']);
	$password = htmlentities($_GET['Password']);

	if(isset($_GET['Login'])){

		if($username=="" && $password==""){
			header("location: ../index.html");
		}else if ($username==""){
			header("location: ../index.html");
		}else if($password==""){
			header("location: ../index.html");
		}else{
			$sqlstmt = $con->prepare("SELECT * FROM patient_information WHERE username=?");
			$sqlstmt->bind_param('s',$username);
			$sqlstmt->execute();
			
			$result = $sqlstmt->get_result();
			$row = mysqli_fetch_assoc($result);
			$p_hash = $row['password'];

			if(password_verify($password, $p_hash)){
				header("location: index.php?PatientID=".$row['PatientID']);
			}else{
				echo "invalid.";
				echo $password." - ".$p_hash;
			}
			
			$sqlstmt->close();
	 	
	 	}
	}elseif (isset($_GET['Register'])) {
			$sqlstmt = $con->prepare("SELECT * FROM patient_information WHERE Username=?");
			$sqlstmt->bind_param('s',$username);
			$sqlstmt->execute();
			
			$result = $sqlstmt->get_result();

			 if ($result->num_rows > 0) {
				 echo "Username is already taken. Please try again.";
			 } else {

			$password_hash = password_hash($password, PASSWORD_BCRYPT, array('cost' => 12));

				$sql = "INSERT INTO patient_information VALUES('','','','','','','','','','$username','$password_hash');";
					 if(mysqli_query($con,$sql)){
						 $sql = "SELECT * FROM patient_information WHERE Username='$username'";
						 $result = $con->query($sql);
						 $array = array();
						 $row = mysqli_fetch_assoc($result);

						 header("location: add_patient.php?PatientID=".$row['PatientID']);
					 }else{
						 echo"Error in insertion ".mysqli_error($con);
					 }

			 }
		mysqli_close($con);
	}