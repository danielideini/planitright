<!DOCTYPE HTML>
<html>

<head>
	<title>PATIENT</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="../CSS/bootstrap.min.css">
	<link rel="stylesheet" href="../CSS/Index.css">
	<link rel="stylesheet" href="../CSS/sweetalert.css">
	<script src="../JS/jquery-1.11.1.min.js"></script>
	<script src="../JS/bootstrap.min.js"></script>
	<script type="text/javascript" src="../JS/sweetalert.min.js"></script>
	<script type="text/javascript" src="../JS/PIndex.js"></script>
	<script type="text/javascript" src="../JS/SaveAllergy.js"></script>


	<?php
		require_once "../INCLUDE/config.php";
	?>
</head>

<body id="IndexBody">
<div id="sidebar">

	<div id="logo-container">
		<div id="logo">
			<img class="menu-logo" src="../IMAGE/logo.jpg">
		</div>
	</div>

		<ul>
			<li>
				<a class="tablink" onclick="openNav(event, 'Profile')">
				<img class="icons" src="../IMAGE/profile.png"><label>Profile</label></a>
			</li>

			<li>
				<a class="tablink" onclick="openNav(event, 'PMeals')">
				<img class="icons" src="../IMAGE/planner.png"><label>Meal Plan</label></a>
			</li>

			<li>
				<a class="tablink" onclick="openNav(event, 'Dietician')">
				<img class="icons" src="../IMAGE/dietician.png"><label>Dietician</label></a>
			</li>

			<li>
				<a class="tablink" id="P_Logout">
				<img class="icons" src="../IMAGE/logout.ico"><label>Log out</label></a>
			</li>
		</ul>

		<div id="sidebar-btn">
				<img class="menu-icon" src="../IMAGE/menu-white.png">
		</div>
</div>

<div id="header">
	<h1 id="head">PLAN IT RIGHT</h1>
</div>

<?php 
	$userID = htmlspecialchars($_GET['PatientID']);	
?>
<div id="container">
 	<div id="Profile" class="tabcontent">
 	<h3>*** Profile ***</h3>
	<?php
			$sql = $con->prepare("SELECT * FROM patient_information WHERE PatientID=?");
			$sql->bind_param('s', $userID);
			$sql->execute();

			$result = $sql->get_result();
			$array = array();
			$row = mysqli_fetch_assoc($result);
			
			$PatientID = $row['PatientID'];
			$PFname = $row['FName'];
			$PLname = $row['LName'];
			$PAge = $row['Age'];
			$PGender = $row['Gender'];
			$PHeight = $row['Height'];
			$PWeight = $row['Weight'];
			$BMI = $row['BMI'];
			$ContactInfo = $row['ContactInfo'];
			//$FAllergy = $array[0]['FAID'];
			// $Diabetic = $array[0]['Diabetic'];
			// $KF = $array[0]['HasKidneyProblem'];
	?>
			<h1> Personal Information </h1>
			<p>Patient ID: <?=$PatientID?></p><br>
			<p>First Name: <?=$PFname?></p><br>
			<p>Last Name: <?=$PLname?></p><br>
			<p>Age: <?=$PAge?></p><br>
			<p>Gender: <?=$PGender?></p><br>
			<p>Height: <?=$PHeight?></p><br>
			<p>Weight: <?=$PWeight?></p><br>
			<p>BMI: <?=$BMI?></p><br>
			<p>Contact Information: <?=$ContactInfo?></p><br>
			<button id='P-Update' onclick="openNav(event, 'Update')">UPDATE</button>
	</div>
	
	<div id="Update" class="tabcontent">
	<h3>*** Update Profile ***</h3>
		<?php 
			if(!isset($_GET['UpdateInfo'])){
				//$sql="SELECT * FROM patient_information WHERE PatientID='$userID'"
		?>

			<form method="GET">
			<p>Patient ID: <?=$PatientID?></p>
			<p>First Name: <input type="text" name="FName" value="<?=$PFname?>"></input></p>
			<p>Last Name: <input type="text" name="LName" value="<?=$PLname?>"></input></p>
			<p>Age: <input type="text" name="UserAge" value="<?=$PAge?>"></input></p>
			<p>Gender: <input type="text" name="UserGender" value="<?=$PGender?>"></input></p>
			<p>Height in meter: <input type="text" name="UserHeight" value="<?=$PHeight?>"></input></p>
			<p>Weight in kg: <input type="text" name="UserWeight" value="<?=$PWeight?>"></input></p>
			<p>Contact No.: <input type="text" name="ContactNumber" value="<?=$ContactInfo?>"></input></p>
			
			<input type="hidden" id="userID" name="PatientID" value="<?=$PatientID?>">
			<input type="hidden" name="PatientID" value="<?=$userID?>">
			
			<label>Allerygic to: </label> <select class="select" id="allergy" name="allergy">
			  <option class="option" value="None">None</option>		
			  <option class="option" value="Milk">Milk</option>
			  <option class="option" value="Peanut">Peanut</option>
			  <option class="option" value="Egg">Egg</option>
			  <option class="option" value="Treenuts">Treenuts</option>
			  <option class="option" value="Soy">Soy</option>
			  <option class="option" value="Fish">Fish</option>
			  <option class="option" value="Wheat">Wheat</option>
			  <option class="option" value="Shellfish">Shellfish</option>
			</select><br><br>
			<input type="submit" id="AddAllergy" value="ADD"></input>
			<br>
			
			<ul id="selectedAllergies">
			</ul><br>
			
			<input type="submit" name="UpdateInfo" value="SAVE">
			</form>
			
		<?php
		}else{
			
			$PID = htmlspecialchars($_GET['PatientID']);
			$Pfname = htmlspecialchars($_GET['FName']);
			$Plname = htmlspecialchars($_GET['LName']);
			$PAge = htmlspecialchars($_GET['UserAge']);
			$PGender = htmlspecialchars($_GET['UserGender']);
			$PHeight = htmlspecialchars($_GET['UserHeight']);
			$PWeight = htmlspecialchars($_GET['UserWeight']);
			$ContactNum = htmlspecialchars($_GET['ContactNumber']);
			$height = $PHeight*$PHeight;
			$BMI = $PWeight/$height;
			//$FAllergy = $_GET['allergy'];
			//$Diabetic = $_GET['diabetic'];
			//$KF = $_GET['KF'];
					
			$sqlUpdate = $con->prepare("Update patient_information SET FName=?, LName=?,Age=?,Gender=?,Height=?,Weight=?, BMI=?, ContactInfo=? WHERE PatientID=?");
			$sqlUpdate->bind_param('sssssssss', $Pfname, $Plname, $PAge,$PGender,$PHeight,$PWeight,$BMI,$ContactNum,$PID);
			$sqlUpdate->execute();
				
			mysqli_close($con);
			header("location: Index.php?PatientID=".$PID);

		}
		?>
		
	</div>

	<div id="PMeals" class="tabcontent Meals">
	<h3>*** Meal Plan ***</h3>
	<?php
		echo "<div id='today'><label id='txt-today'>TODAY:</label><strong> ".date("M d, Y")."</strong></div>";
	?>
	
	<div id="AP_datepicker">
		<label> Check your day plan: </label><br><input type="date" id="datepicker">
		<input type="hidden" id="PIID" value="<?=$userID?>">
	</div>

	<div id="futureplan">
		<p>Enter # of days: 
		<select id="numOfDays">
			<option class="planoption" value=7>7 days ahead</option>
			<option class="planoption" value=30>30 days ahead</option>
		</select>
		</p>
		<button id="AddFPlan">Generate Meals</button>

		<p id='ul'>
		</p>

	</div>
	
	<div id="dayplan">
	<?php
			$userID = $_GET['PatientID'];
			$date = date("Y-m-d");

			$sql="SELECT * FROM meal_plan WHERE Date='$date' and PatientID='".$userID."'";
			$result = mysqli_query($con,$sql);
			$numRows = mysqli_num_rows($result);

			$stat = 0;
			$B = 0;
			$L = 0;
			$D = 0;

				while($row = mysqli_fetch_assoc($result)){
						$stat++;						
						$numRows--;
						$sql="SELECT * FROM recipes WHERE RecipeNum='".$row['RecipeID']."' AND Type='B'";
						if($resultB=mysqli_query($con,$sql)){
							$numRow = mysqli_num_rows($resultB);
							$rowB = mysqli_fetch_assoc($resultB);
								if($numRow > 0 ){
									echo "<form action='RecipeDetails.php' method='POST'>
									<input type='hidden' name='PatientID' value='".$userID."'>
									<input type='hidden' name='RecipeNum' value='".$rowB['RecipeNum']."'>
									<button class='BLD-btn' id='Breakfast' name='Type' value='Breakfast'>BREAKFAST</button>
									</form><br>
									<ul><li id='bfast'>".$rowB['RecipeName']."</li></ul>";	
									
									echo "<form method='POST' action='RecipeDetails.php'>
									<input type='hidden' name='RecipeNum' value='".$rowB['RecipeNum']."'>
									<input type='hidden' name='PatientID' value='".$userID."'>
									<input type='submit' name='remove' value='REMOVE'></input>
									</form>";
									$B++;
									
								}elseif($numRow==0 && $numRows==0 && $B == 0){
									echo "<form action='Recipes.php' method='POST'>
									<input type='hidden' name='PatientID' value='".$userID."'>
								
									<button class='BLD-btn' id='Breakfast' name='Type' value='Breakfast'>BREAKFAST</button>
									</form><br>
									<ul><li id='bfast'>Nothing yet.</li></ul>";
									$B++;
								}else{
									
								}
						}else{
							echo"Error updating ".mysqli_error($con);
							mysqli_close($con);
						}
						
						$sql="SELECT * FROM recipes WHERE RecipeNum='".$row['RecipeID']."' AND Type='L'";
						if($resultL=mysqli_query($con,$sql)){
							$numRow = mysqli_num_rows($resultL);
							$rowL = mysqli_fetch_assoc($resultL);
							
								if($numRow > 0 ){
									echo "<form action='RecipeDetails.php' method='POST'>
									<input type='hidden' name='PatientID' value='".$userID."'>
									<input type='hidden' name='RecipeNum' value='".$rowL['RecipeNum']."'>
									<button class='BLD-btn' id='Lunch' name='Type' value='Lunch'>LUNCH</button>
									</form><br>
									<ul><li id='bfast'>".$rowL['RecipeName']."</li></ul>";
									
									echo "<form method='POST' action='RecipeDetails.php'>
									<input type='hidden' name='RecipeNum' value='".$rowL['RecipeNum']."'>
									<input type='hidden' name='PatientID' value='".$userID."'>
									<input type='submit' name='remove' value='REMOVE'></input>
									</form>";
									$L++;
								}elseif($numRow==0 && $numRows==0 && $L == 0){
									echo "<form action='Recipes.php' method='POST'>
									<input type='hidden' name='PatientID' value='".$userID."'>
									
									<button class='BLD-btn' id='Lunch' name='Type' value='Lunch'>LUNCH</button>
									</form><br>
									<ul><li id='lunch'>Nothing yet.</li></ul>";
									$L++;
								}
						}else{
							echo"Error updating ".mysqli_error($con);
							mysqli_close($con);
						}
						
						$sql="SELECT * FROM recipes WHERE RecipeNum='".$row['RecipeID']."' AND Type='D'";
						if($resultD = mysqli_query($con,$sql)){
							$numRow = mysqli_num_rows($resultD);
							$rowD = mysqli_fetch_assoc($resultD);
							
								if($numRow > 0 ){								
									echo "<form action='RecipeDetails.php' method='POST'>
									<input type='hidden' name='PatientID' value='".$userID."'>
									<input type='hidden' name='RecipeNum' value='".$rowD['RecipeNum']."'>
									<button class='BLD-btn' id='Dinner' name='Type' value='Dinner'>DINNER</button>
									</form><br>
									<ul><li id='bfast'>".$rowD['RecipeName']."</li></ul>";
									
									echo "<form method='POST' action='RecipeDetails.php'>
									<input type='hidden' name='RecipeNum' value='".$rowD['RecipeNum']."'>
									<input type='hidden' name='PatientID' value='".$userID."'>
									<input type='submit' name='remove' value='REMOVE'></input>
									</form>";
									$D++;
								}elseif($numRow==0 && $numRows==0 && $D == 0){
									
									echo "<form action='Recipes.php' method='POST'>
									<input type='hidden' name='PatientID' value='".$userID."'>
									
									<button class='BLD-btn' id='Dinner' name='Type' value='Dinner'>DINNER</button>
									</form><br>
									<ul><li id='dinner'>Nothing yet.</li></ul>";
									$D++;
								}
						}else{
							echo"Error updating ".mysqli_error($con);
							mysqli_close($con);
						}
						
					}

					if($numRows == 0 && $stat==0){
						echo "<form action='../PHP/Recipes.php' method='POST'>
									<input type='hidden' name='PatientID' value='".$userID."'>
									
									<button class='BLD-btn' id='Breakfast' name='Type' value='Breakfast'>BREAKFAST</button>
									</form><br>
									<ul><li id='bfast'>Nothing yet.</li></ul>";
						echo "<form action='../PHP/Recipes.php' method='POST'>
									<input type='hidden' name='PatientID' value='".$userID."'>
									
									<button class='BLD-btn' id='Lunch' name='Type' value='Lunch'>LUNCH</button>
									</form><br>
									<ul><li id='bfast'>Nothing yet.</li></ul>";
						echo "<form action='../PHP/Recipes.php' method='POST'>
									<input type='hidden' name='PatientID' value='".$userID."'>
									
									<button class='BLD-btn' id='Dinner' name='Type' value='Dinner'>DINNER</button>
									</form><br>
									<ul><li id='bfast'>Nothing yet.</li></ul>";
					}		

	?>

		<div id="planahead">
			<button id="APlanning">ADVANCE PLANNING</button>
		</div>
	</div>
	
	</div>

	
	<div id="Dietician" class="tabcontent">
	  <h3>Dietician</h3>

	  <p>Contact Information:</p>
	  <?php
		$sql="SELECT FirstName, LastName, ContactNumber FROM dietician_info";
		$result = mysqli_query($con, $sql);
		if(mysqli_query($con,$sql)){
			while($row = mysqli_fetch_assoc($result)){
				echo "Name: ".$row['FirstName']." ".$row['LastName']."<br>";
				echo "Contact Number: ".$row['ContactNumber']."<br><br>";
			}
		}else{
				echo"Error reading ".mysqli_error($con);
				mysqli_close($con);
		}
	  
	  ?>
	</div>
</div>
</body>
</html>