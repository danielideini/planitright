<!DOCTYPE HTML>
<html>
<head>
	<title>DIETICIAN</title>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="../CSS/Index.css">
	<script src="../JS/jquery-1.11.1.min.js"></script>
	<script type="text/javascript" src="../JS/PIndex.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>


<body id="RecipeBody">
<?php
	require_once "../INCLUDE/config.php";
?>
<ul id="recipes">
	<?php
		$type = $_POST['Type'];
		$PID = $_POST['PatientID'];
		$array = array(); // array where recipe id is stored

		//retrieving patient's Allergies
		$sqlPA = $con->prepare("SELECT * FROM patient_allergies WHERE PatientID=?");
		$sqlPA->bind_param('s', $PID);
		$sqlPA->execute();
		$resultPA = $sqlPA->get_result();
		
		if($resultPA){ // if succeeded
			while($rowPA = mysqli_fetch_assoc($resultPA)){ // loop results to -->
				$patientAllergy = $rowPA['FoodAllergy'];
				
				// retrieving IDs of recipes with patient's allergy
				$sqlFA = "SELECT RecipeID FROM perrecipeallergies WHERE AllergyName='$patientAllergy'";
				$resultFA = mysqli_query($con, $sqlFA);
			
				if($resultFA){ // if succeeded
					
					while($rowFA = mysqli_fetch_assoc($resultFA)){ // loop to add all of the id with allergies to an array
						$RecipeWithAllergy = $rowFA['RecipeID'];
						array_push($array, $RecipeWithAllergy);	
						//adding recipe id to the array 
					}
					
				}else{
					echo"Error reading ".mysqli_error($con);
					mysqli_close($con);
				}
			}
			
			$arrayRecipe = implode(',', $array); // convert array to string
			
		}else{
			echo"Error reading ".mysqli_error($con);
			mysqli_close($con);
		}
		
		//Selecting Recipes based on type and allergens
		
		if(isset($type) && $type=="Breakfast"){
		$sql="SELECT * FROM recipes where Type='B' AND RecipeNum NOT IN (".$arrayRecipe.")";	
		$result = mysqli_query($con,$sql);
			
			if(mysqli_query($con,$sql)){
					while($row = mysqli_fetch_assoc($result))
					{
						echo "<form action='RecipeDetails.php' method='POST'><li>
						<button class='Recipe-list-btn' name='RecipeNum' value='".$row['RecipeNum']."'>".$row['RecipeName']."</button>
						<input type='hidden' name='PatientID' value=".$PID.">
						<input type='hidden' name='Type'>
						</li></form>";
					}
					
				}else{
					echo"Error reading".mysqli_error($con);
					mysqli_close($con);
				}
				
		}else if(isset($type) && $type=="Lunch"){
		$sql="SELECT * FROM recipes where Type='L' AND RecipeNum NOT IN ('".$arrayRecipe."')";	
		$result = mysqli_query($con,$sql);
				if(mysqli_query($con,$sql)){
					while($row = mysqli_fetch_assoc($result))
					{
						echo "<form action='RecipeDetails.php' method='POST'><li>
						<button  class='Recipe-list-btn'  name='RecipeNum' value='".$row['RecipeNum']."'>".$row['RecipeName']."</button>
						<input type='hidden' name='PatientID' value=".$PID.">
						<input type='hidden' name='Type'>
						</li></form>";
					}
				}else{
					echo"Error reading ".mysqli_error($con);
					mysqli_close($con);
				}
		}else if(isset($type) && $type=="Dinner"){
		$sql="SELECT * FROM recipes where Type='D' AND RecipeNum NOT IN ('".$arrayRecipe."')";	
		$result = mysqli_query($con,$sql);
			if(mysqli_query($con,$sql)){
					while($row = mysqli_fetch_assoc($result))
					{
						echo "<form action='RecipeDetails.php' method='POST'><li>
						<button  class='Recipe-list-btn' name='RecipeNum' value='".$row['RecipeNum']."'>".$row['RecipeName']."</button>
						<input type='hidden' name='PatientID' value=".$PID.">
						<input type='hidden' name='Type'>
						</li></form>";
					}
				}else{
					echo"Error reading ".mysqli_error($con);
					mysqli_close($con);
				}
		}			
	?>
</ul>
</body>
</html>