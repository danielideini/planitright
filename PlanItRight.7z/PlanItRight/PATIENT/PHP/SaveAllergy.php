<?php

include_once "../INCLUDE/config.php";

if(isset($_POST["Allergy"])) 
{	
	$FoodAllergy = $_POST["Allergy"]; 
	$PID = $_GET["PatientID"];
	
	$sql = "INSERT INTO patient_allergies VALUES ('','$PID','$FoodAllergy');";
		if(mysqli_query($con,$sql)){
			$my_id = mysql_insert_id();
			echo '<li>';
			echo $FoodAllergy.'</li>';
		}else{
			 echo"Error in insertion ".mysqli_error($con);
		}	
}

if(isset($_POST['Date']) && isset($_POST['PatientID'])) 
{	
	$date = $_POST["Date"]; 
	$userID = $_POST['PatientID'];
	$today = date("Y-m-d");

?>
	<div id="dayplan">
	<?php

	if ($date==$today){
			
			$sql="SELECT * FROM meal_plan WHERE Date='$date' and PatientID='".$userID."'";
			$result = mysqli_query($con,$sql);
			$numRows = mysqli_num_rows($result);
			$stat = 0;
			$B = 0;
			$L = 0;
			$D = 0;

				while($row = mysqli_fetch_assoc($result)){
						$stat++;						
						$numRows--;
						$sql="SELECT * FROM recipes WHERE RecipeNum='".$row['RecipeID']."' AND Type='B'";
						if($resultB=mysqli_query($con,$sql)){
							$numRow = mysqli_num_rows($resultB);
							$rowB = mysqli_fetch_assoc($resultB);
								if($numRow > 0 ){
									echo "<form action='RecipeDetails.php' method='POST'>
									<input type='hidden' name='PatientID' value='".$userID."'>
									<input type='hidden' name='RecipeNum' value='".$rowB['RecipeNum']."'>
									<button class='BLD-btn' id='Breakfast' name='Type' value='Breakfast'>BREAKFAST</button>
									</form><br>
									<ul><li id='bfast'>".$rowB['RecipeName']."</li></ul>";	
									
									echo "<form method='POST' action='RecipeDetails.php'>
									<input type='hidden' name='RecipeNum' value='".$rowB['RecipeNum']."'>
									<input type='hidden' name='PatientID' value='".$userID."'>
									<input type='submit' name='remove' value='REMOVE'></input>
									</form>";
									$B++;
									
								}elseif($numRow==0 && $numRows==0 && $B == 0){
									echo "<form action='Recipes.php' method='POST'>
									<input type='hidden' name='PatientID' value='".$userID."'>
								
									<button class='BLD-btn' id='Breakfast' name='Type' value='Breakfast'>BREAKFAST</button>
									</form><br>
									<ul><li id='bfast'>Nothing yet.</li></ul>";
									$B++;
								}else{
									
								}
						}else{
							echo"Error updating ".mysqli_error($con);
							mysqli_close($con);
						}
						
						$sql="SELECT * FROM recipes WHERE RecipeNum='".$row['RecipeID']."' AND Type='L'";
						if($resultL=mysqli_query($con,$sql)){
							$numRow = mysqli_num_rows($resultL);
							$rowL = mysqli_fetch_assoc($resultL);
							
								if($numRow > 0 ){
									echo "<form action='RecipeDetails.php' method='POST'>
									<input type='hidden' name='PatientID' value='".$userID."'>
									<input type='hidden' name='RecipeNum' value='".$rowL['RecipeNum']."'>
									<button class='BLD-btn' id='Lunch' name='Type' value='Lunch'>LUNCH</button>
									</form><br>
									<ul><li id='bfast'>".$rowL['RecipeName']."</li></ul>";
									
									echo "<form method='POST' action='RecipeDetails.php'>
									<input type='hidden' name='RecipeNum' value='".$rowL['RecipeNum']."'>
									<input type='hidden' name='PatientID' value='".$userID."'>
									<input type='submit' name='remove' value='REMOVE'></input>
									</form>";
									$L++;
								}elseif($numRow==0 && $numRows==0 && $L == 0){
									echo "<form action='Recipes.php' method='POST'>
									<input type='hidden' name='PatientID' value='".$userID."'>
									
									<button class='BLD-btn' id='Lunch' name='Type' value='Lunch'>LUNCH</button>
									</form><br>
									<ul><li id='lunch'>Nothing yet.</li></ul>";
									$L++;
								}
						}else{
							echo"Error updating ".mysqli_error($con);
							mysqli_close($con);
						}
						
						$sql="SELECT * FROM recipes WHERE RecipeNum='".$row['RecipeID']."' AND Type='D'";
						if($resultD = mysqli_query($con,$sql)){
							$numRow = mysqli_num_rows($resultD);
							$rowD = mysqli_fetch_assoc($resultD);
							
								if($numRow > 0 ){								
									echo "<form action='RecipeDetails.php' method='POST'>
									<input type='hidden' name='PatientID' value='".$userID."'>
									<input type='hidden' name='RecipeNum' value='".$rowD['RecipeNum']."'>
									<button class='BLD-btn' id='Dinner' name='Type' value='Dinner'>DINNER</button>
									</form><br>
									<ul><li id='bfast'>".$rowD['RecipeName']."</li></ul>";
									
									echo "<form method='POST' action='RecipeDetails.php'>
									<input type='hidden' name='RecipeNum' value='".$rowD['RecipeNum']."'>
									<input type='hidden' name='PatientID' value='".$userID."'>
									<input type='submit' name='remove' value='REMOVE'></input>
									</form>";
									$D++;
								}elseif($numRow==0 && $numRows==0 && $D == 0){
									
									echo "<form action='Recipes.php' method='POST'>
									<input type='hidden' name='PatientID' value='".$userID."'>
									
									<button class='BLD-btn' id='Dinner' name='Type' value='Dinner'>DINNER</button>
									</form><br>
									<ul><li id='dinner'>Nothing yet.</li></ul>";
									$D++;
								}
						}else{
							echo"Error updating ".mysqli_error($con);
							mysqli_close($con);
						}
						
					}

					if($numRows == 0 && $stat==0){
						echo "<form action='../PHP/Recipes.php' method='POST'>
									<input type='hidden' name='PatientID' value='".$userID."'>
									
									<button class='BLD-btn' id='Breakfast' name='Type' value='Breakfast'>BREAKFAST</button>
									</form><br>
									<ul><li id='bfast'>Nothing yet.</li></ul>";
						echo "<form action='../PHP/Recipes.php' method='POST'>
									<input type='hidden' name='PatientID' value='".$userID."'>
									
									<button class='BLD-btn' id='Lunch' name='Type' value='Lunch'>LUNCH</button>
									</form><br>
									<ul><li id='bfast'>Nothing yet.</li></ul>";
						echo "<form action='../PHP/Recipes.php' method='POST'>
									<input type='hidden' name='PatientID' value='".$userID."'>
									
									<button class='BLD-btn' id='Dinner' name='Type' value='Dinner'>DINNER</button>
									</form><br>
									<ul><li id='bfast'>Nothing yet.</li></ul>";
					}

			}elseif ($date!=$today) {
				$sql="SELECT * FROM meal_plan WHERE Date='$date' and PatientID='".$userID."'";
				$result = mysqli_query($con,$sql);
				$numRows = mysqli_num_rows($result);
				$stat = 0;
				$B = 0;
				$L = 0;
				$D = 0;

				while($row = mysqli_fetch_assoc($result)){
						$stat++;						
						$numRows--;
						$sql="SELECT * FROM recipes WHERE RecipeNum='".$row['RecipeID']."' AND Type='B'";
						if($resultB=mysqli_query($con,$sql)){
							$numRow = mysqli_num_rows($resultB);
							$rowB = mysqli_fetch_assoc($resultB);
								if($numRow > 0 ){
									echo "
									<input type='hidden' name='PatientID' value='".$userID."'>
									<input type='hidden' name='RecipeNum' value='".$rowB['RecipeNum']."'>
									<button class='BLD-btn' id='Breakfast' name='Type' value='Breakfast'>BREAKFAST</button>
									<br>
									<ul><li id='bfast'>".$rowB['RecipeName']."</li></ul>";	
									$B++;
									
								}elseif($numRow==0 && $numRows==0 && $B == 0){
									echo "
									<input type='hidden' name='PatientID' value='".$userID."'>
								
									<button class='BLD-btn' id='Breakfast' name='Type' value='Breakfast'>BREAKFAST</button>
									<br>
									<ul><li id='bfast'>Nothing</li></ul>";
									$B++;
								}else{
									
								}
						}else{
							echo"Error updating ".mysqli_error($con);
							mysqli_close($con);
						}
						
						$sql="SELECT * FROM recipes WHERE RecipeNum='".$row['RecipeID']."' AND Type='L'";
						if($resultL=mysqli_query($con,$sql)){
							$numRow = mysqli_num_rows($resultL);
							$rowL = mysqli_fetch_assoc($resultL);
							
								if($numRow > 0 ){
									echo "
									<input type='hidden' name='PatientID' value='".$userID."'>
									<input type='hidden' name='RecipeNum' value='".$rowL['RecipeNum']."'>
									<button class='BLD-btn' id='Lunch' name='Type' value='Lunch'>LUNCH</button>
									<br>
									<ul><li id='bfast'>".$rowL['RecipeName']."</li></ul>";
									
									$L++;
								}elseif($numRow==0 && $numRows==0 && $L == 0){
									echo "
									<input type='hidden' name='PatientID' value='".$userID."'>
									
									<button class='BLD-btn' id='Lunch' name='Type' value='Lunch'>LUNCH</button>
									<br>
									<ul><li id='lunch'>Nothing yet.</li></ul>";
									$L++;
								}
						}else{
							echo"Error updating ".mysqli_error($con);
							mysqli_close($con);
						}
						
						$sql="SELECT * FROM recipes WHERE RecipeNum='".$row['RecipeID']."' AND Type='D'";
						if($resultD = mysqli_query($con,$sql)){
							$numRow = mysqli_num_rows($resultD);
							$rowD = mysqli_fetch_assoc($resultD);
							
								if($numRow > 0 ){								
									echo "
									<input type='hidden' name='PatientID' value='".$userID."'>
									<input type='hidden' name='RecipeNum' value='".$rowD['RecipeNum']."'>
									<button class='BLD-btn' id='Dinner' name='Type' value='Dinner'>DINNER</button>
									<br>
									<ul><li id='bfast'>".$rowD['RecipeName']."</li></ul>";
									
									$D++;
								}elseif($numRow==0 && $numRows==0 && $D == 0){
									
									echo "
									<input type='hidden' name='PatientID' value='".$userID."'>
									
									<button class='BLD-btn' id='Dinner' name='Type' value='Dinner'>DINNER</button>
									<br>
									<ul><li id='dinner'>Nothing</li></ul>";
									$D++;
								}
						}else{
							echo"Error updating ".mysqli_error($con);
							mysqli_close($con);
						}
						
					}

					if($numRows == 0 && $stat==0){
						echo "
									<input type='hidden' name='PatientID' value='".$userID."'>
									
									<button class='BLD-btn' id='Breakfast' name='Type' value='Breakfast'>BREAKFAST</button>
									<br>
									<ul><li id='bfast'>Nothing</li></ul>";
						echo "
									<input type='hidden' name='PatientID' value='".$userID."'>
									
									<button class='BLD-btn' id='Lunch' name='Type' value='Lunch'>LUNCH</button>
									<br>
									<ul><li id='bfast'>Nothing</li></ul>";
						echo "
									<input type='hidden' name='PatientID' value='".$userID."'>
									
									<button class='BLD-btn' id='Dinner' name='Type' value='Dinner'>DINNER</button>
									<br>
									<ul><li id='bfast'>Nothing</li></ul>";
					}

			}	

	?>
	</div>
	<?php
}


if(isset($_POST['numOfDays'])){

	$num = htmlspecialchars($_POST['numOfDays']);
	$UserID = htmlspecialchars($_POST['PatientID']);
	$date = date("Y-m-d");

	$sqlToday = $con->prepare("SELECT * FROM meal_plan WHERE Date=? AND PatientID=?");
	$sqlToday->bind_param('ss', $date, $UserID);
	$sqlToday->execute();

	$result = $sqlToday->get_result();
	$count = mysqli_num_rows($result);
	
	if($count==0){
	 	
			$arrayofRecipes = array();
			
			$sqlAllgy=$con->prepare("SELECT * FROM patient_allergies WHERE PatientID=?"); // retrieving patient's allergies

			$sqlAllgy->bind_param('s', $UserID);
			$sqlAllgy->execute();
			
			$resultAllgy = $sqlAllgy->get_result();

			while($rowAllgy = mysqli_fetch_assoc($resultAllgy)){

				// echo "<br>Name: ".$rowAllgy['FoodAllergy']." ID: ".$rowAllgy['PatientID'];

				$sqlFA=$con->prepare("SELECT * FROM perrecipeallergies WHERE AllergyName = ?"); 
				//retrieving recipe allergens where the allergy name the same sa the patient's allergy
				$sqlFA->bind_param('s', $rowAllgy['FoodAllergy']);
				$sqlFA->execute();
				
				$resultFA = $sqlFA->get_result();

					while($rowFA = mysqli_fetch_assoc($resultFA)){
						//echo $RecipeWithAllergy;
						array_push($arrayofRecipes, $rowFA['RecipeID']);	
					}
			}
		

		$RecipeArray=implode(',', $arrayofRecipes);
	
		$dateB = date("Y-m-d");
		$dateL = date("Y-m-d");
		$dateD = date("Y-m-d");

		$deytB = strtotime($dateB);
		$deytL = strtotime($dateL);
		$deytD = strtotime($dateD);

		$B=1;
		$L=1;
		$D=1;

		$d;

		$sqlG= $con->prepare("SELECT * FROM recipes WHERE RecipeNum not in (".$RecipeArray.")");	
		$sqlG->execute();


			if($resultG = $sqlG->get_result()){
			
				while($rowG = mysqli_fetch_assoc($resultG)){
					if($rowG['Type']=='B' && $B<=$num){
							$RID = $rowG['RecipeNum'];
							
							$sqlB= $con->prepare("INSERT INTO meal_plan values (?,?,?,?)");
							$sqlB->bind_param('ssss', $d, $dateB, $RID, $UserID);
							$sqlB->execute();

							$deytB = strtotime("+1 day", $deytB);
							$dateB = date('Y-m-d', $deytB);
							$B++;

					}elseif($rowG['Type']=='L' && $L<=$num){
							$RID = $rowG['RecipeNum'];
							
							$sqlL= $con->prepare("INSERT INTO meal_plan values (?,?,?,?)");
							$sqlL->bind_param('ssss', $d, $dateL, $RID, $UserID);
							$sqlL->execute();
							
							$deytL = strtotime("+1 day", $deytL);
							$dateL = date('Y-m-d', $deytL);
							$L++;

					}elseif($rowG['Type']=='D' && $D<=$num){
							$RID = $rowG['RecipeNum'];
							
							$sqlD= $con->prepare("INSERT INTO meal_plan values (?,?,?,?)");
							$sqlD->bind_param('ssss', $d, $dateD, $RID, $UserID);
							$sqlD->execute();

							$deytD = strtotime("+1 day", $deytD);
							$dateD = date('Y-m-d', $deytD);
							$D++;
					}
				}
				
			}else{
				echo"Error in insertion ".mysqli_error($con);
				mysqli_close($con);
			}

	}else{

		$sqlMaxDate = $con->prepare("SELECT Max(Date) FROM meal_plan");
		$sqlMaxDate->execute();
		
		$result = $sqlMaxDate->get_result();

		$row = mysqli_fetch_assoc($result);
		echo "You already have an existing plan for today would you like to advance it starting from your plan expiration date dated".$row['Max('.'Date'.')']."?";


	}
}
