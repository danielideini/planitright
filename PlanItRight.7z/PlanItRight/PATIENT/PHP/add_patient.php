<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="../CSS/Index.css">
	<link rel="stylesheet" href="../CSS/sweetalert.css">
	<script src="../JS/jquery-1.11.1.min.js"></script>
	<script type="text/javascript" src="../JS/sweetalert.min.js"></script>
	<script type="text/javascript" src="../JS/SaveAllergy.js"></script> 
	<?php
		require_once "../INCLUDE/config.php";
	?>

	<title>PLAN IT RIGHT</title>
	
</head>
<body id="PatientBody">

<?php 
	if(!isset($_POST['AddInfo'])){
		$UID=$_GET['PatientID'];
?>
<div id="head">
	<h1>PLAN IT RIGHT</h1>
</div>
<div id="addPatient">
	<form method="POST">
			<p>First Name: <input type="text" name="FName"></input></p>
			<p>Last Name: <input type="text" name="LName"></input></p>
			<p>Age: <input type="text" name="UserAge"></input></p>
			
			<label>Gender: </label> <select class="select" name="UserGender">
				<option value="male"> Male</option>	
				<option value="female">Female</option>
			</select><br><br>

			<!-- <p>Gender: <input type="text" name="UserGender"></input></p> -->
			<p>Height in meter: <input type="text" name="UserHeight"></input></p>
			<p>Weight in kg: <input type="text" name="UserWeight"></input></p>
			<p>Contact No.: <input type="text" name="ContactNumber"></input></p>
		
		<label>Allerygic to: </label> <select class="select" name="allergy" id="allergy">
				<option value=""></option>	
			  <option class="option" value="Milk">Milk</option>
			  <option class="option" value="Peanut">Peanut</option>
			  <option class="option" value="Egg">Egg</option>
			  <option class="option" value="Treenuts">Treenuts</option>
			  <option class="option" value="Soy">Soy</option>
			  <option class="option" value="Fish">Fish</option>
			  <option class="option" value="Wheat">Wheat</option>
			  <option class="option" value="Shellfish">Shellfish</option>
		</select><br><br>
		<input type="submit" id="AddAllergy" value="ADD"></input>
		<br>
		
		<ul id="selectedAllergies">
		</ul><br>
		
		<!-- <label>Diabetic? </label> <select class="select" name="diabetic">
		  <option class="option" value="No">No</option>
		  <option class="option" value="Yes">Yes</option>		  
		</select><br>
		
		<label>Do you have kidney failure? </label> <select class="select" name="KF">
		  <option class="option" value="No">No</option>
		  <option class="option" value="Yes">Yes</option>		  
		</select><br> -->
		
		<input type="hidden" id="userID" name="ID" value="<?=$UID?>">
		<input type="submit" id="P_Add_Patient" name="AddInfo" value="SAVE">
	</form>
	</div>
	
<?php
	}else{

		$Fname=htmlspecialchars($_POST["FName"]);
		$LName = htmlspecialchars($_POST["LName"]);
		$age=htmlspecialchars($_POST["UserAge"]);
		$gender=htmlspecialchars($_POST["UserGender"]);
		$PHeight=htmlspecialchars($_POST["UserHeight"]);
		$PWeight=htmlspecialchars($_POST["UserWeight"]);
		$contactNum = htmlspecialchars($_POST["ContactNumber"]);
		$height = $PHeight*$PHeight;
		$BMI = $PWeight/$height;
		$foodAllergy = htmlspecialchars($_POST['allergy']);
		// $diabetic = htmlspecialchars($_POST['diabetic']);
		// $KF = htmlspecialchars($_POST['KF']);
		// $UserID = htmlspecialchars($_POST['ID']);

		$sqlUpdate = $con->prepare("Update patient_information SET FName=?, LName=?,Age=?,Gender=?,Height=?,Weight=?, BMI=?, ContactInfo=? WHERE PatientID=?");
		$sqlUpdate->bind_param('sssssssss', $Fname, $LName, $age,$gender,$PHeight,$PWeight,$BMI,$contactNum,$UserID);
		$sqlUpdate->execute();
		
			$arrayofRecipes = array();
			
			$sqlAllgy=$con->prepare("SELECT * FROM patient_allergies WHERE PatientID=?"); // retrieving patient's allergies

			$sqlAllgy->bind_param('s', $UserID);
			$sqlAllgy->execute();
			
			$resultAllgy = $sqlAllgy->get_result();

			while($rowAllgy = mysqli_fetch_assoc($resultAllgy)){

				// echo "<br>Name: ".$rowAllgy['FoodAllergy']." ID: ".$rowAllgy['PatientID'];

				$sqlFA=$con->prepare("SELECT * FROM perrecipeallergies WHERE AllergyName = ?"); 
				//retrieving recipe allergens where the allergy name the same sa the patient's allergy
				$sqlFA->bind_param('s', $rowAllgy['FoodAllergy']);
				$sqlFA->execute();
				
				$resultFA = $sqlFA->get_result();

					while($rowFA = mysqli_fetch_assoc($resultFA)){
						
						$RecipeWithAllergy = $rowFA['RecipeID'];
						echo $RecipeWithAllergy;
						array_push($arrayofRecipes, $RecipeWithAllergy);	
					}
			}
		

		$RecipeArray=implode(',' , $arrayofRecipes);
		//echo $RecipeArray;

		$dateB = date("Y-m-d");
		$dateL = date("Y-m-d");
		$dateD = date("Y-m-d");

		$deytB = strtotime($dateB);
		$deytL = strtotime($dateL);
		$deytD = strtotime($dateD);

		$B=1;
		$L=1;
		$D=1;
		$d;
		

		$sqlG= $con->prepare("SELECT * FROM recipes WHERE RecipeNum NOT IN ('?')");
		$sqlG->bind_param('s', $RecipeArray);
		$sqlG->execute();


			if($resultG = $sqlG->get_result()){
			
				while($rowG = mysqli_fetch_assoc($resultG)){
					if($rowG['Type']=='B' && $B<=7){
							$RID = $rowG['RecipeNum'];
							
							$sqlB= $con->prepare("INSERT INTO meal_plan values (?,?,?,?)");
							$sqlB->bind_param('ssss', $d, $dateB, $RID, $UserID);
							$sqlB->execute();

							$deytB = strtotime("+1 day", $deytB);
							$dateB = date('Y-m-d', $deytB);
							$B++;

					}elseif($rowG['Type']=='L' && $L<=7){
							$RID = $rowG['RecipeNum'];
							
							$sqlL= $con->prepare("INSERT INTO meal_plan values (?,?,?,?)");
							$sqlL->bind_param('ssss', $d, $dateL, $RID, $UserID);
							$sqlL->execute();
							
							$deytL = strtotime("+1 day", $deytL);
							$dateL = date('Y-m-d', $deytL);
							$L++;

					}elseif($rowG['Type']=='D' && $D<=7){
							$RID = $rowG['RecipeNum'];
							
							$sqlD= $con->prepare("INSERT INTO meal_plan values (?,?,?,?)");
							$sqlD->bind_param('ssss', $d, $dateD, $RID, $UserID);
							$sqlD->execute();

							$deytD = strtotime("+1 day", $deytD);
							$dateD = date('Y-m-d', $deytD);
							$D++;
					}
				}
				
			}else{
				echo"Error in insertion ".mysqli_error($con);
				mysqli_close($con);
			}
			header("location: Index.php?PatientID=".$UserID);
}
?>
</body>
</html>