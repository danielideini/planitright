<?php
	require_once "../INCLUDE/config.php";
	
	$RID = $_POST['RecipeID'];
	$date = date("Y-m-d");
	$PID = $_POST['PatientID'];
	
	if(isset($_POST['AddToMealsPlan'])){
		$sql = "INSERT INTO meal_plan VALUES('','$date','$RID','$PID')";
			if(mysqli_query($con,$sql)){
					mysqli_close($con);
					header("location: Index.php?PatientID=".$PID);
				}else{
					echo"Error saving meal. ".mysqli_error($con);
					mysqli_close($con);
				}
		
	}
?>