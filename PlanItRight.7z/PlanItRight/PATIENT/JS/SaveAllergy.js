$(function(){
	$('#sidebar-btn').click(function(){
		$('#sidebar').toggleClass('visible');
		$('#sidebar-btn').hide();
	});

	$('#container').click(function(){
		//alert("g");
		$('#sidebar').removeClass('visible');
		$('#sidebar-btn').show();
	})

	$('li').click(function(){
		//alert("g");
		$('#sidebar').removeClass('visible');
		$('#sidebar-btn').show();
	})

	$("#AddAllergy").click(function (e) {
			// alert($("#DieticianID").val());
			e.preventDefault();
			if($("#allergy").val()== " ")
			{
				alert("You have not selected anything from allergy dropdown list.");
			}
				var myData = 'Allergy='+ $("#allergy").val();
				jQuery.ajax({
				type: "POST",
				url: "../PHP/SaveAllergy.php?PatientID="+$("#userID").val(),
				dataType: "text",
				data: myData,
				
				success:function(response){
					$("#selectedAllergies").append(response);
				},
				error:function (xhr, ajaxOptions, thrownError){
					alert(thrownError);
				}
				});
	});
	
	$("#P_Logout").click(function (e) {
		swal({
		  title: "Are you sure?",
		  text: "You are about to log out!",
		  type: "warning",
		  showCancelButton: true,
		  confirmButtonColor: "#DD6B55",
		  confirmButtonText: "Yes, log me out!",
		  cancelButtonText: "No, I'll stay!",
		  closeOnConfirm: false,
		  closeOnCancel: false
		},
		function(isConfirm){
		  if (isConfirm) {
			swal("","You have successfully logged out.","success");
			setTimeout(function () {
			   window.location.replace("../Index.html")
			}, 2000);
		  } else {
			swal("Cancelled", "Thank you for staying :)", "error");
		  }
		});
	});
	
	$("#P_Add_Patient").click(function (e) {
		$userID = $("#userID").val();
		swal("We would like to inform you that we have already prepared a one week meal plan for you.You can change it to your preferred meal anytime! Have a heppy meal :)");
		setTimeout(function () {
		    window.location.replace("../PHP/Index.php?PatientID="+$userID);
		}, 2000);
	});
	
	$("#dayplan").show();
	$("#futureplan").hide();
	
	
	$("#APlanning").click(function(){

		$('#APlanning').hide();
		$("#dayplan").hide();
		$("#AP_datepicker").hide();
		$("#futureplan").show();

	});

	$('#AddFPlan').click(function(e){
		e.preventDefault();

		var num = 'numOfDays=' + $("#numOfDays").val();
		var id = '&PatientID=' + $("#PIID").val();
		jQuery.ajax({
		type: "POST",
		url: "../PHP/SaveAllergy.php",
		dataType: "text",
		data: num+id,
		
		success:function(response){
			//$("#ul").append(response);
			location.reload();
		},error:function (xhr, ajaxOptions, thrownError){
			alert(thrownError);
		}

		});

	});
	
	$("#datepicker").change(function(){
	//	e.preventDefault();
			
				var date = 'Date=' + $("#datepicker").val();
				var PID = '&PatientID=' + $("#PIID").val();
				jQuery.ajax({
				type: "POST",
				url: "../PHP/SaveAllergy.php",
				dataType: "text",
				data: date+PID,
				
				success:function(response){
					$("#dayplan").replaceWith(response);
				},
				error:function (xhr, ajaxOptions, thrownError){
					alert(thrownError);
				}
				});
	});

	$('#RetypePass').hide();

	$('#Register').click(function(){

		if($('#Username').val() == ""){
			$('p').replaceWith("<p>Username required!</p>");
			$('#Username').css('borderColor', 'red');
		
		}else if($('#Password').val() == ""){
			$('p').replaceWith("<p>Password required!</p>");
			$('#Password').css('borderColor', 'red');

		}else if(($('#Password').val()!="") && ($('#RetypePass').val()=="")){

			$('#RetypePass').show();
			$('p').replaceWith("<p></p>");

		}else if($('#Password').val() == $('#RetypePass').val()){

			var uname = 'Username=' + $("#Username").val();
			var pass = '&Password=' + $("#Password").val();

			window.location.replace("./PHP/PatientLogin.php?Register=REJ&"+uname+pass);

		}else if($('#Password').val()!=$('#RetypePass').val()){
			$('p').replaceWith("<p>Password mismatch! Please try again.</p>");
		}

	});

	$('#Login').click(function(){

		var username =  $("#Username").val();
		var password =  $("#Password").val();

		var uname = 'Username=' + $("#Username").val();
		var pass = '&Password=' + $("#Password").val();

		if(username==""){
			$('p').replaceWith("<p>Username required!</p>");
			$('#Username').css('borderColor', 'red');
		}else if(password==""){
			$('p').replaceWith("<p>Password required!</p>");
			$('#Password').css('borderColor', 'red');
		}else{
			window.location.replace("./PHP/PatientLogin.php?Login=Log&"+uname+pass);
		}

	});
	
});